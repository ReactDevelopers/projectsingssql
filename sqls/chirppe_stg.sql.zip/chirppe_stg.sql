-- phpMyAdmin SQL Dump
-- version 4.0.10.17
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 25, 2018 at 12:49 PM
-- Server version: 5.1.73-log
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `chirppe_stg`
--

-- --------------------------------------------------------

--
-- Table structure for table `c_activities`
--

CREATE TABLE IF NOT EXISTS `c_activities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `comments` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `c_attendance`
--

CREATE TABLE IF NOT EXISTS `c_attendance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `class_id` int(10) unsigned NOT NULL,
  `present` enum('active','inactive') COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `attendance_user_id_foreign` (`user_id`),
  KEY `attendance_class_id_foreign` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `c_attendees`
--

CREATE TABLE IF NOT EXISTS `c_attendees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `status` enum('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `c_attendees`
--

INSERT INTO `c_attendees` (`id`, `parent_id`, `event_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 69, 1, 'pending', '2018-01-17 22:44:47', '2018-01-17 22:44:47'),
(2, 106, 5, 'pending', '2018-01-24 01:48:36', '2018-01-24 01:48:36'),
(3, 107, 5, 'pending', '2018-01-24 01:48:36', '2018-01-24 01:48:36'),
(4, 97, 6, 'pending', '2018-01-24 04:17:38', '2018-01-24 04:17:38');

-- --------------------------------------------------------

--
-- Table structure for table `c_broadcast`
--

CREATE TABLE IF NOT EXISTS `c_broadcast` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `principal_id` int(10) NOT NULL,
  `type` enum('general','draft','event') NOT NULL DEFAULT 'draft',
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `c_broadcast`
--

INSERT INTO `c_broadcast` (`id`, `principal_id`, `type`, `title`, `description`, `start_date`, `end_date`, `created_at`, `updated_at`) VALUES
(1, 2, 'general', 'Parent Teacher Meeting', 'Parent Teacher Meeting', NULL, NULL, '2018-01-17 22:44:47', '2018-01-17 22:44:47'),
(2, 77, 'event', 'Parent Teacher Meeting', '"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"', '2018-01-25 07:00:00', '2018-03-21 07:00:00', '2018-01-20 01:27:52', '2018-01-20 01:27:52'),
(3, 77, 'event', 'Parent Teacher Meeting', '"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"', '2018-01-25 07:00:00', '2018-03-21 07:00:00', '2018-01-20 01:28:34', '2018-01-20 01:28:34'),
(4, 77, 'general', 'Trip to Bangalore', '"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"', NULL, NULL, '2018-01-20 01:30:29', '2018-01-20 01:30:29'),
(5, 92, 'event', 'Broadcast1', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '2018-01-25 07:00:00', '2018-01-31 07:00:00', '2018-01-24 01:48:36', '2018-01-24 01:48:36'),
(6, 90, 'event', 'Annual Function', 'test test test test', '2018-03-01 09:00:00', '2018-03-01 17:00:00', '2018-01-24 04:17:38', '2018-01-24 04:17:38'),
(7, 77, 'event', 'New Broadcast', 'Testing', '2018-01-26 07:00:00', '2018-01-28 07:00:00', '2018-01-24 12:32:35', '2018-01-24 12:32:35'),
(8, 77, 'event', 'Broadcast created by Raveena', 'Broadcast created by Raveena', '2018-01-24 07:00:00', '2018-01-26 07:00:00', '2018-01-24 12:44:55', '2018-01-24 12:44:55');

-- --------------------------------------------------------

--
-- Table structure for table `c_bulletboard`
--

CREATE TABLE IF NOT EXISTS `c_bulletboard` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `attending` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `c_chats`
--

CREATE TABLE IF NOT EXISTS `c_chats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message_id` varchar(255) DEFAULT NULL,
  `message` text CHARACTER SET utf8,
  `sender_id` int(11) DEFAULT NULL,
  `receiver_id` int(11) DEFAULT NULL,
  `message_type` enum('text','image','video','file') NOT NULL DEFAULT 'text',
  `seen_status` enum('sending','sent','delivered','read') NOT NULL DEFAULT 'sent',
  `delete_sender_status` enum('active','trashed') NOT NULL DEFAULT 'active',
  `delete_receiver_status` enum('active','trashed') NOT NULL DEFAULT 'active',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `c_chats`
--

INSERT INTO `c_chats` (`id`, `message_id`, `message`, `sender_id`, `receiver_id`, `message_type`, `seen_status`, `delete_sender_status`, `delete_receiver_status`, `created_at`, `updated_at`) VALUES
(1, 'WEBMESSAGE_9099581180604', 'hello principal', 83, 2, 'text', 'read', 'active', 'active', '2018-01-22 04:54:28', '2018-01-22 04:54:28'),
(2, 'WEBMESSAGE_10616178258308', 'yo boy', 83, 2, 'text', 'delivered', 'active', 'active', '2018-01-22 04:54:59', '2018-01-22 04:54:59'),
(3, 'WEBMESSAGE_16684822749947', 'Hello', 78, 77, 'text', 'delivered', 'active', 'active', '2018-01-24 13:54:43', '2018-01-24 13:54:44'),
(4, 'WEBMESSAGE_21235235056770', 'hi', 92, 93, 'text', 'delivered', 'active', 'active', '2018-01-24 14:01:59', '2018-01-24 14:02:00'),
(5, 'WEBMESSAGE_3033605054286', '<p>hi', 92, 93, 'text', 'delivered', 'active', 'active', '2018-01-24 14:02:22', '2018-01-24 14:02:22'),
(6, 'WEBMESSAGE_10617617748612', '<b>good', 92, 93, 'text', 'delivered', 'active', 'active', '2018-01-24 14:02:31', '2018-01-24 14:02:31'),
(7, 'WEBMESSAGE_22752038931315', 'good''', 93, 92, 'text', 'delivered', 'active', 'active', '2018-01-24 14:03:30', '2018-01-24 14:03:30'),
(8, 'WEBMESSAGE_6067210399984', 'nops''', 93, 92, 'text', 'delivered', 'active', 'active', '2018-01-24 14:03:35', '2018-01-24 14:03:35'),
(9, 'WEBMESSAGE_13651223433408', 'hi', 93, 92, 'text', 'delivered', 'active', 'active', '2018-01-24 14:03:38', '2018-01-24 14:03:39'),
(10, 'WEBMESSAGE_7584264750070', 'Hello', 91, 90, 'text', 'delivered', 'active', 'active', '2018-01-25 04:02:45', '2018-01-25 04:02:45'),
(11, 'WEBMESSAGE_15168530127090', 'Who is this?', 90, 91, 'text', 'read', 'active', 'active', '2018-01-25 04:03:47', '2018-01-25 04:03:47'),
(12, 'WEBMESSAGE_16685383449449', 'this is chanchal', 91, 90, 'text', 'read', 'active', 'active', '2018-01-25 04:04:15', '2018-01-25 04:04:16'),
(13, 'WEBMESSAGE_6067415201524', 'sdffbjdnk', 91, 90, 'text', 'read', 'active', 'active', '2018-01-25 04:16:55', '2018-01-25 04:16:55'),
(14, 'WEBMESSAGE_7584269008710', 'jdfkjskjd', 91, 90, 'text', 'read', 'active', 'active', '2018-01-25 04:16:56', '2018-01-25 04:16:56'),
(15, 'WEBMESSAGE_10617976625599', 'bdsbfdfs', 91, 90, 'text', 'read', 'active', 'active', '2018-01-25 04:16:58', '2018-01-25 04:16:58'),
(16, 'WEBMESSAGE_12134830727624', 'dfghjklkdlksd bfsjfkjjfkl fbsflsdl bfkslfsl fbsjnflksfls hsfslkf;ls iueowijoewk hefosjfsldf jkfksdjflsjdfl nvvnxnv,x jljfejfslf heirorojfkf jkdfkjgouoeru fkdbvvkefioeje hfjskfdnerhferrhfr uhrfjknsfndsdmf fbjfjskkfs hdsfkjsdfhksff skfbjkdshfkslkfd fbksjkjsdjfksfdl bksjdfnkdsnfklsfds vdjfhiewfh', 91, 90, 'text', 'read', 'active', 'active', '2018-01-25 04:17:36', '2018-01-25 04:17:36'),
(17, 'WEBMESSAGE_1516853878481', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 90, 91, 'text', 'read', 'active', 'active', '2018-01-25 04:18:13', '2018-01-25 04:18:13'),
(18, 'WEBMESSAGE_25786516084151', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 90, 91, 'text', 'read', 'active', 'active', '2018-01-25 04:18:22', '2018-01-25 04:18:22'),
(19, 'WEBMESSAGE_25786517990055', ':p', 91, 90, 'text', 'read', 'active', 'active', '2018-01-25 04:20:14', '2018-01-25 04:20:14'),
(20, 'WEBMESSAGE_24269664104960', ':P', 91, 90, 'text', 'read', 'active', 'active', '2018-01-25 04:20:21', '2018-01-25 04:20:21'),
(21, 'WEBMESSAGE_7584270076005', '@#$%^&*()(*&^%$#@!@#$%^&*()*&^%$#@!~@#$%^&*()*&^%$#@1', 91, 90, 'text', 'read', 'active', 'active', '2018-01-25 04:20:30', '2018-01-25 04:20:30'),
(22, 'WEBMESSAGE_19719102531648', '!@#$%^&*()!@#$%^&*()!@#$%^&*()!@#$%^&*()(*&^%$#@!@#$%^&*(*&^%$#@ !@#$%^&*()(*&^%$#@!@#$%^&*()(*&^%$#@!@#$%^&*((*&^%$#@ 2345^&*()', 90, 91, 'text', 'read', 'active', 'active', '2018-01-25 04:20:55', '2018-01-25 04:20:56');

-- --------------------------------------------------------

--
-- Table structure for table `c_classrooms`
--

CREATE TABLE IF NOT EXISTS `c_classrooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `principal_id` int(11) DEFAULT NULL,
  `classTitle` varchar(255) DEFAULT NULL,
  `classStatus` enum('0','1') DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `c_classrooms`
--

INSERT INTO `c_classrooms` (`id`, `principal_id`, `classTitle`, `classStatus`, `created_at`, `updated_at`) VALUES
(1, 2, 'Class 1', '1', '2017-12-24 14:02:26', '2017-12-24 14:02:26'),
(2, 2, 'Class 2', '1', '2017-12-24 14:02:34', '2017-12-24 14:02:34'),
(3, 2, 'Class 3', '1', '2017-12-24 14:02:34', '2017-12-24 14:02:34'),
(4, 2, 'Class 4', '1', '2017-12-24 14:02:34', '2017-12-24 14:02:34'),
(5, 2, 'Class 5', '1', '2017-12-24 14:02:34', '2017-12-24 14:02:34'),
(6, 2, 'Class 6', '1', '2017-12-24 14:02:34', '2017-12-24 14:02:34'),
(7, 2, 'Class 7', '1', '2017-12-24 14:02:34', '2017-12-24 14:02:34'),
(8, 2, 'Class 8', '1', '2017-12-24 14:02:34', '2017-12-24 14:02:34'),
(9, 2, 'Class 9', '1', '2017-12-24 14:02:34', '2017-12-24 14:02:34'),
(10, 2, 'Class 10', '1', '2017-12-24 14:02:34', '2017-12-24 14:02:34'),
(11, 2, 'kinder', '1', '2018-01-06 06:29:33', '2018-01-06 06:29:33'),
(12, 77, 'Lower KG', '1', '2018-01-09 12:23:28', '2018-01-10 04:17:26'),
(13, 77, 'Upper KG', '1', '2018-01-09 12:23:44', '2018-01-20 08:15:29'),
(14, 84, 'Kindergarden Pre', '1', '2018-01-22 09:48:59', '2018-01-22 09:48:59'),
(15, 84, 'Kindergarden Sec', '1', '2018-01-22 10:03:39', '2018-01-22 10:03:39'),
(16, 90, 'Pre nursery', '1', '2018-01-24 05:06:39', '2018-01-24 05:06:39'),
(17, 90, 'K.G.', '1', '2018-01-24 05:07:46', '2018-01-24 05:07:46'),
(18, 90, 'K.G.', '1', '2018-01-24 05:13:02', '2018-01-24 05:13:02'),
(19, 90, 'class 1', '1', '2018-01-24 05:15:21', '2018-01-24 05:15:21'),
(23, 90, 'Pre nursery', '1', '2018-01-24 05:40:14', '2018-01-24 05:40:14'),
(27, 92, 'Nursery', '1', '2018-01-24 05:43:11', '2018-01-24 05:43:11'),
(29, 92, '1st', '1', '2018-01-24 05:49:05', '2018-01-24 05:49:05'),
(32, 92, '2nd', '1', '2018-01-24 05:57:35', '2018-01-24 05:57:35'),
(38, 96, 'Nursery', '1', '2018-01-24 08:22:58', '2018-01-24 08:22:58'),
(39, 96, 'Nursery', '1', '2018-01-24 08:27:29', '2018-01-24 08:27:29'),
(40, 96, 'Nursery', '1', '2018-01-24 08:28:02', '2018-01-24 08:28:02'),
(41, 96, 'Nursery', '1', '2018-01-24 08:28:12', '2018-01-24 08:28:12'),
(43, 77, 'Pre Kindergarden 02', '1', '2018-01-24 18:39:11', '2018-01-24 18:39:11');

-- --------------------------------------------------------

--
-- Table structure for table `c_classroom_student`
--

CREATE TABLE IF NOT EXISTS `c_classroom_student` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class_id` int(10) unsigned NOT NULL,
  `std_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `classroom_student_class_id_foreign` (`class_id`),
  KEY `classroom_student_std_id_foreign` (`std_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=97 ;

--
-- Dumping data for table `c_classroom_student`
--

INSERT INTO `c_classroom_student` (`id`, `class_id`, `std_id`, `created_at`, `updated_at`) VALUES
(1, 13, 23, '2018-01-12 11:18:16', '2018-01-12 11:18:16'),
(2, 12, 24, '2018-01-12 11:18:16', '2018-01-12 11:18:16'),
(3, 16, 0, '2018-01-23 23:36:52', '2018-01-23 23:36:52'),
(4, 16, 0, '2018-01-23 23:36:58', '2018-01-23 23:36:58'),
(5, 16, 0, '2018-01-23 23:37:00', '2018-01-23 23:37:00'),
(6, 17, 0, '2018-01-23 23:38:11', '2018-01-23 23:38:11'),
(7, 17, 0, '2018-01-23 23:38:13', '2018-01-23 23:38:13'),
(8, 17, 0, '2018-01-23 23:38:13', '2018-01-23 23:38:13'),
(9, 17, 0, '2018-01-23 23:38:13', '2018-01-23 23:38:13'),
(10, 17, 0, '2018-01-23 23:38:13', '2018-01-23 23:38:13'),
(11, 17, 0, '2018-01-23 23:38:14', '2018-01-23 23:38:14'),
(12, 17, 0, '2018-01-23 23:38:14', '2018-01-23 23:38:14'),
(13, 17, 0, '2018-01-23 23:38:14', '2018-01-23 23:38:14'),
(14, 17, 0, '2018-01-23 23:38:14', '2018-01-23 23:38:14'),
(15, 17, 0, '2018-01-23 23:38:14', '2018-01-23 23:38:14'),
(16, 33, 90, '2018-01-24 00:42:34', '2018-01-24 00:42:34'),
(17, 33, 90, '2018-01-24 00:42:36', '2018-01-24 00:42:36'),
(18, 33, 90, '2018-01-24 00:42:43', '2018-01-24 00:42:43'),
(19, 33, 90, '2018-01-24 00:42:44', '2018-01-24 00:42:44'),
(20, 33, 90, '2018-01-24 00:42:45', '2018-01-24 00:42:45'),
(21, 33, 90, '2018-01-24 00:42:45', '2018-01-24 00:42:45'),
(22, 33, 90, '2018-01-24 00:42:45', '2018-01-24 00:42:45'),
(23, 33, 90, '2018-01-24 00:42:45', '2018-01-24 00:42:45'),
(24, 33, 90, '2018-01-24 00:42:46', '2018-01-24 00:42:46'),
(25, 33, 90, '2018-01-24 00:42:46', '2018-01-24 00:42:46'),
(26, 33, 90, '2018-01-24 00:42:46', '2018-01-24 00:42:46'),
(27, 33, 90, '2018-01-24 00:43:37', '2018-01-24 00:43:37'),
(28, 33, 90, '2018-01-24 00:43:37', '2018-01-24 00:43:37'),
(29, 33, 90, '2018-01-24 00:43:38', '2018-01-24 00:43:38'),
(30, 33, 90, '2018-01-24 00:43:38', '2018-01-24 00:43:38'),
(31, 33, 90, '2018-01-24 00:43:38', '2018-01-24 00:43:38'),
(32, 33, 90, '2018-01-24 00:43:38', '2018-01-24 00:43:38'),
(33, 33, 90, '2018-01-24 00:43:39', '2018-01-24 00:43:39'),
(34, 33, 90, '2018-01-24 00:43:39', '2018-01-24 00:43:39'),
(35, 33, 90, '2018-01-24 00:43:39', '2018-01-24 00:43:39'),
(36, 33, 90, '2018-01-24 00:43:39', '2018-01-24 00:43:39'),
(37, 33, 90, '2018-01-24 00:43:40', '2018-01-24 00:43:40'),
(38, 33, 90, '2018-01-24 00:43:40', '2018-01-24 00:43:40'),
(39, 33, 90, '2018-01-24 00:43:40', '2018-01-24 00:43:40'),
(40, 33, 90, '2018-01-24 00:43:40', '2018-01-24 00:43:40'),
(41, 33, 90, '2018-01-24 00:43:40', '2018-01-24 00:43:40'),
(42, 33, 90, '2018-01-24 00:43:43', '2018-01-24 00:43:43'),
(43, 33, 90, '2018-01-24 00:43:45', '2018-01-24 00:43:45'),
(44, 33, 90, '2018-01-24 00:43:45', '2018-01-24 00:43:45'),
(45, 33, 90, '2018-01-24 00:43:59', '2018-01-24 00:43:59'),
(46, 33, 90, '2018-01-24 00:43:59', '2018-01-24 00:43:59'),
(47, 33, 90, '2018-01-24 00:44:00', '2018-01-24 00:44:00'),
(48, 33, 90, '2018-01-24 00:45:22', '2018-01-24 00:45:22'),
(49, 33, 90, '2018-01-24 00:45:23', '2018-01-24 00:45:23'),
(50, 33, 90, '2018-01-24 00:45:23', '2018-01-24 00:45:23'),
(51, 33, 90, '2018-01-24 00:45:23', '2018-01-24 00:45:23'),
(52, 33, 90, '2018-01-24 00:45:23', '2018-01-24 00:45:23'),
(53, 33, 90, '2018-01-24 00:45:24', '2018-01-24 00:45:24'),
(54, 33, 90, '2018-01-24 00:49:01', '2018-01-24 00:49:01'),
(55, 33, 90, '2018-01-24 00:49:01', '2018-01-24 00:49:01'),
(56, 33, 90, '2018-01-24 00:49:01', '2018-01-24 00:49:01'),
(57, 33, 90, '2018-01-24 00:49:03', '2018-01-24 00:49:03'),
(58, 33, 90, '2018-01-24 00:49:03', '2018-01-24 00:49:03'),
(59, 33, 90, '2018-01-24 00:49:04', '2018-01-24 00:49:04'),
(60, 33, 90, '2018-01-24 00:49:04', '2018-01-24 00:49:04'),
(61, 33, 90, '2018-01-24 00:49:26', '2018-01-24 00:49:26'),
(62, 33, 90, '2018-01-24 00:49:26', '2018-01-24 00:49:26'),
(63, 33, 90, '2018-01-24 00:49:26', '2018-01-24 00:49:26'),
(64, 33, 90, '2018-01-24 00:49:26', '2018-01-24 00:49:26'),
(65, 12, 77, '2018-01-24 03:40:17', '2018-01-24 03:40:17'),
(66, 12, 77, '2018-01-24 03:40:19', '2018-01-24 03:40:19'),
(67, 43, 77, '2018-01-24 13:09:25', '2018-01-24 13:09:25'),
(68, 43, 77, '2018-01-24 13:09:25', '2018-01-24 13:09:25'),
(69, 43, 77, '2018-01-24 13:09:27', '2018-01-24 13:09:27'),
(70, 43, 77, '2018-01-24 13:09:27', '2018-01-24 13:09:27'),
(71, 43, 77, '2018-01-24 13:09:28', '2018-01-24 13:09:28'),
(72, 43, 77, '2018-01-24 13:09:28', '2018-01-24 13:09:28'),
(73, 43, 77, '2018-01-24 13:09:28', '2018-01-24 13:09:28'),
(74, 43, 77, '2018-01-24 13:09:28', '2018-01-24 13:09:28'),
(75, 43, 77, '2018-01-24 13:09:28', '2018-01-24 13:09:28'),
(76, 43, 77, '2018-01-24 13:09:29', '2018-01-24 13:09:29'),
(77, 43, 77, '2018-01-24 13:09:29', '2018-01-24 13:09:29'),
(78, 43, 77, '2018-01-24 13:09:29', '2018-01-24 13:09:29'),
(79, 43, 77, '2018-01-24 13:09:29', '2018-01-24 13:09:29'),
(80, 43, 77, '2018-01-24 13:09:29', '2018-01-24 13:09:29'),
(81, 43, 77, '2018-01-24 13:09:29', '2018-01-24 13:09:29'),
(82, 43, 77, '2018-01-24 13:09:29', '2018-01-24 13:09:29'),
(83, 43, 77, '2018-01-24 13:09:30', '2018-01-24 13:09:30'),
(84, 43, 77, '2018-01-24 13:09:30', '2018-01-24 13:09:30'),
(85, 43, 77, '2018-01-24 13:09:30', '2018-01-24 13:09:30'),
(86, 43, 77, '2018-01-24 13:09:30', '2018-01-24 13:09:30'),
(87, 43, 77, '2018-01-24 13:09:30', '2018-01-24 13:09:30'),
(88, 43, 77, '2018-01-24 13:09:30', '2018-01-24 13:09:30'),
(89, 43, 77, '2018-01-24 13:09:30', '2018-01-24 13:09:30'),
(90, 43, 77, '2018-01-24 13:09:30', '2018-01-24 13:09:30'),
(91, 43, 77, '2018-01-24 13:09:46', '2018-01-24 13:09:46'),
(92, 43, 77, '2018-01-24 13:09:46', '2018-01-24 13:09:46'),
(93, 43, 77, '2018-01-24 13:12:45', '2018-01-24 13:12:45'),
(94, 43, 77, '2018-01-24 13:12:45', '2018-01-24 13:12:45'),
(95, 43, 77, '2018-01-24 13:14:21', '2018-01-24 13:14:21'),
(96, 43, 77, '2018-01-24 13:14:21', '2018-01-24 13:14:21');

-- --------------------------------------------------------

--
-- Table structure for table `c_classroom_teacher`
--

CREATE TABLE IF NOT EXISTS `c_classroom_teacher` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class_id` int(10) unsigned NOT NULL,
  `teacher_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `classroom_teacher_class_id_foreign` (`class_id`),
  KEY `classroom_teacher_teacher_id_foreign` (`teacher_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=53 ;

--
-- Dumping data for table `c_classroom_teacher`
--

INSERT INTO `c_classroom_teacher` (`id`, `class_id`, `teacher_id`, `created_at`, `updated_at`) VALUES
(4, 1, 42, '2017-12-25 06:19:30', '2017-12-25 06:19:30'),
(5, 1, 43, '2017-12-25 11:34:21', '2017-12-25 11:34:21'),
(6, 1, 44, '2017-12-25 18:38:57', '2017-12-25 18:38:57'),
(7, 3, 45, '2017-12-25 18:41:44', '2017-12-25 18:41:44'),
(8, 1, 53, '2018-01-01 18:32:47', '2018-01-01 18:32:47'),
(9, 1, 54, '2018-01-01 22:09:25', '2018-01-01 22:09:25'),
(10, 1, 55, '2018-01-01 22:10:32', '2018-01-01 22:10:32'),
(11, 1, 56, '2018-01-01 22:11:40', '2018-01-01 22:11:40'),
(12, 1, 57, '2018-01-01 22:13:21', '2018-01-01 22:13:21'),
(13, 1, 58, '2018-01-01 22:15:51', '2018-01-01 22:15:51'),
(14, 1, 59, '2018-01-01 22:16:26', '2018-01-01 22:16:26'),
(15, 1, 61, '2018-01-01 22:52:43', '2018-01-01 22:52:43'),
(16, 1, 62, '2018-01-01 22:54:44', '2018-01-01 22:54:44'),
(17, 1, 63, '2018-01-01 22:56:20', '2018-01-01 22:56:20'),
(18, 1, 64, '2018-01-01 22:58:35', '2018-01-01 22:58:35'),
(19, 1, 65, '2018-01-01 22:59:13', '2018-01-01 22:59:13'),
(20, 1, 66, '2018-01-02 00:00:44', '2018-01-02 00:00:44'),
(21, 1, 67, '2018-01-02 00:01:52', '2018-01-02 00:01:52'),
(22, 11, 42, '2018-01-05 19:29:33', '2018-01-05 19:29:33'),
(23, 11, 43, '2018-01-05 19:29:33', '2018-01-05 19:29:33'),
(24, 12, 78, '2018-01-09 06:53:28', '2018-01-09 06:53:28'),
(25, 12, 79, '2018-01-09 06:53:28', '2018-01-09 06:53:28'),
(26, 13, 78, '2018-01-09 06:53:44', '2018-01-09 06:53:44'),
(28, 14, 85, '2018-01-22 04:18:59', '2018-01-22 04:18:59'),
(29, 15, 85, '2018-01-22 04:33:40', '2018-01-22 04:33:40'),
(30, 15, 86, '2018-01-22 04:33:40', '2018-01-22 04:33:40'),
(31, 16, 91, '2018-01-23 23:36:39', '2018-01-23 23:36:39'),
(32, 17, 91, '2018-01-23 23:37:46', '2018-01-23 23:37:46'),
(33, 18, 91, '2018-01-23 23:43:02', '2018-01-23 23:43:02'),
(34, 21, 91, '2018-01-23 23:58:01', '2018-01-23 23:58:01'),
(35, 22, 93, '2018-01-24 00:07:23', '2018-01-24 00:07:23'),
(36, 23, 91, '2018-01-24 00:10:14', '2018-01-24 00:10:14'),
(37, 26, 93, '2018-01-24 00:11:58', '2018-01-24 00:11:58'),
(38, 27, 93, '2018-01-24 00:13:11', '2018-01-24 00:13:11'),
(39, 29, 93, '2018-01-24 00:19:05', '2018-01-24 00:19:05'),
(40, 32, 93, '2018-01-24 00:27:35', '2018-01-24 00:27:35'),
(41, 33, 91, '2018-01-24 00:42:24', '2018-01-24 00:42:24'),
(42, 34, 94, '2018-01-24 01:36:59', '2018-01-24 01:36:59'),
(43, 35, 78, '2018-01-24 01:48:37', '2018-01-24 01:48:37'),
(44, 36, 94, '2018-01-24 01:57:39', '2018-01-24 01:57:39'),
(45, 37, 94, '2018-01-24 01:58:27', '2018-01-24 01:58:27'),
(46, 38, 98, '2018-01-24 02:52:59', '2018-01-24 02:52:59'),
(47, 39, 98, '2018-01-24 02:57:29', '2018-01-24 02:57:29'),
(48, 40, 98, '2018-01-24 02:58:02', '2018-01-24 02:58:02'),
(49, 41, 98, '2018-01-24 02:58:12', '2018-01-24 02:58:12'),
(51, 43, 78, '2018-01-24 13:09:11', '2018-01-24 13:09:11'),
(52, 43, 79, '2018-01-24 13:09:11', '2018-01-24 13:09:11');

-- --------------------------------------------------------

--
-- Table structure for table `c_configs`
--

CREATE TABLE IF NOT EXISTS `c_configs` (
  `key` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `value` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `c_configs`
--

INSERT INTO `c_configs` (`key`, `value`) VALUES
('admin_theme', 'skin-aquamarine2'),
('contact_number', '+65 63375474'),
('copyright_text', 'Copyright © 2017 Chirppe'),
('default_latitude', ''),
('default_longitude', ''),
('download_app_text', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'),
('download_app_title', 'Download App'),
('format_date', 'd/m/Y'),
('format_time', 'h:i A'),
('full_address', '42, IInd St, Chapel \r\nJurong Island\r\nSingapore 675656'),
('help_email', 'support@chirppe.com'),
('info_email', 'info@chirppe.com'),
('newsletter_text', 'Subscribe to our newsletter to get the updates and know what’s happening around We don’t spam.'),
('newsletter_title', 'Stay In touch'),
('office_address', 'Address to be changed'),
('otp_expired', '5000'),
('otp_length', '6'),
('otp_message', 'Thank you for using Chirppe. Your OTP is %s.'),
('otp_shuffle', '45987343049568802934857637283746574839234567902394856775483929384529384756783293845789'),
('postman_collection', ''),
('site_description', 'Lorem ipsum dolor sit amet, Lorem ipsum'),
('site_email', 'info@chirppe.com'),
('site_environment', 'development'),
('site_name', 'Chirppe Web Portal'),
('smtp_host', 'smtp.gmail.com'),
('smtp_mode', 'tls'),
('smtp_password', 'rituyadav'),
('smtp_port', '587'),
('smtp_username', 'singsys17@gmail.com'),
('social_facebook_url', 'https://facebook.com'),
('social_googleplus_url', 'https://plus.google.com/'),
('social_instagram_url', 'https://instagram.com'),
('social_linkedin_url', 'https://linkedin.com'),
('social_twitter_url', 'https://twitter.com');

-- --------------------------------------------------------

--
-- Table structure for table `c_consent_attendees`
--

CREATE TABLE IF NOT EXISTS `c_consent_attendees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `consent_form_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `status` enum('pending','accepted','rejected') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `c_consent_attendees`
--

INSERT INTO `c_consent_attendees` (`id`, `consent_form_id`, `class_id`, `student_id`, `parent_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 0, 23, 81, 'pending', '2018-01-20 03:57:06', '2018-01-20 03:57:06'),
(2, 1, 0, 24, 82, 'pending', '2018-01-20 03:57:06', '2018-01-20 03:57:06'),
(3, 2, 0, 28, 97, 'pending', '2018-01-24 05:02:10', '2018-01-24 05:02:10'),
(4, 2, 0, 29, 99, 'pending', '2018-01-24 05:02:10', '2018-01-24 05:02:10');

-- --------------------------------------------------------

--
-- Table structure for table `c_consent_form`
--

CREATE TABLE IF NOT EXISTS `c_consent_form` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `venue` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `template` text NOT NULL,
  `save_as` enum('0','1') NOT NULL DEFAULT '0',
  `participants` enum('students','classes') NOT NULL,
  `status` enum('active','archive') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `c_consent_form`
--

INSERT INTO `c_consent_form` (`id`, `teacher_id`, `title`, `date`, `venue`, `description`, `template`, `save_as`, `participants`, `status`, `created_at`, `updated_at`) VALUES
(1, 78, 'Trip to Singapore', '2018-01-20 04:00:00', 'Singapore', 'But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. \r\nNo one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it? But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?', '<p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth,</p>\r\n\r\n<p><em>the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. </em></p>\r\n\r\n<p><strong>Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.</strong></p>\r\n\r\n<p><span style="color:#1abc9c">To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it?</span> <span style="color:#9b59b6">But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?</span></p>', '0', 'students', 'active', '2018-01-20 03:57:06', '2018-01-20 03:57:06'),
(2, 91, 'Excursion Title', '2018-01-25 04:30:00', 'omaxe', 'test test test test test', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recentl</p>', '0', 'students', 'active', '2018-01-24 05:02:09', '2018-01-24 05:02:09'),
(3, 91, 'Title 1', '2018-01-24 13:42:55', 'omaxe', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recentl', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recentl</p>', '0', 'classes', 'active', '2018-01-24 05:47:20', '2018-01-24 08:12:55');

-- --------------------------------------------------------

--
-- Table structure for table `c_email_template`
--

CREATE TABLE IF NOT EXISTS `c_email_template` (
  `email_template_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email_template_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `c_email_template`
--

INSERT INTO `c_email_template` (`email_template_id`, `title`, `subject`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Chirppe_account_confirmation', 'Chirppe Web Portal - Account Confirmation', 'Dear {NAME},\r\n\r\nYour account is activated on {SITENAME}. Visit our {WEBSITE}  and  use below credentials to login into the application:\r\n\r\nEmail: {EMAIL}\r\nPassword: {PASSWORD}\r\n\r\nThanks {SITENAME}', '2017-12-04 11:23:53', '2018-01-05 00:19:16');

-- --------------------------------------------------------

--
-- Table structure for table `c_event_repeat`
--

CREATE TABLE IF NOT EXISTS `c_event_repeat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `repeat_id` int(11) NOT NULL,
  `short_description` enum('Does Not Repeat','Daily','Weekly On Monday','Monthly On The First Monday','Annual On January 1','Custom') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `c_event_repeat`
--

INSERT INTO `c_event_repeat` (`id`, `repeat_id`, `short_description`, `created_at`, `updated_at`) VALUES
(1, 1, 'Does Not Repeat', '2017-12-04 16:53:53', '2017-12-04 16:53:53'),
(2, 2, 'Daily', '2017-12-04 16:53:53', '2017-12-04 16:53:53'),
(3, 3, 'Weekly On Monday', '2017-12-04 16:53:53', '2017-12-04 16:53:53'),
(4, 4, 'Monthly On The First Monday', '2017-12-04 16:53:53', '2017-12-04 16:53:53'),
(5, 5, 'Annual On January 1', '2017-12-04 16:53:53', '2017-12-04 16:53:53'),
(6, 6, 'Custom', '2017-12-04 16:53:53', '2017-12-04 16:53:53');

-- --------------------------------------------------------

--
-- Table structure for table `c_feedback`
--

CREATE TABLE IF NOT EXISTS `c_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `feedback` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `c_feedback`
--

INSERT INTO `c_feedback` (`id`, `user_id`, `feedback`, `created_at`, `updated_at`) VALUES
(1, 96, 'vdfjhkj', '2018-01-24 01:09:00', '2018-01-24 01:09:00');

-- --------------------------------------------------------

--
-- Table structure for table `c_feedback_attach`
--

CREATE TABLE IF NOT EXISTS `c_feedback_attach` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `feedback_id` int(11) NOT NULL,
  `media` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `c_feedback_attach`
--

INSERT INTO `c_feedback_attach` (`id`, `feedback_id`, `media`, `created_at`, `updated_at`) VALUES
(1, 1, '1516775940-infinity war.jpg', '2018-01-24 01:09:00', '2018-01-24 01:09:00');

-- --------------------------------------------------------

--
-- Table structure for table `c_gallery`
--

CREATE TABLE IF NOT EXISTS `c_gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `comments` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `c_invitation_codes`
--

CREATE TABLE IF NOT EXISTS `c_invitation_codes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `invitation_code` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('pending','active') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invitation_code_user_id_foreign` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=75 ;

--
-- Dumping data for table `c_invitation_codes`
--

INSERT INTO `c_invitation_codes` (`id`, `user_id`, `invitation_code`, `status`, `created_at`, `updated_at`) VALUES
(7, 35, 'VZRAHVDGOL', 'pending', '2017-12-25 09:12:55', '2017-12-25 09:12:55'),
(8, 36, 'HHTIGLHLKJ', 'active', '2017-12-25 09:13:02', '2017-12-25 09:16:22'),
(9, 37, 'YMRB7LCC3O', 'pending', '2017-12-25 11:41:23', '2017-12-25 11:41:23'),
(11, 42, 'XCYHR779MK', 'active', '2017-12-25 22:49:30', '2017-12-25 22:51:09'),
(12, 43, 'NW2M9VSZAU', 'active', '2017-12-26 04:04:21', '2017-12-26 04:05:12'),
(13, 44, 'QZEJNIP1YJ', 'pending', '2017-12-26 05:38:57', '2017-12-26 05:38:57'),
(14, 45, 'EFYMGLTT30', 'pending', '2017-12-26 05:41:45', '2017-12-26 05:41:45'),
(15, 46, '640D064VFM', 'pending', '2017-12-26 05:51:33', '2017-12-26 05:51:33'),
(16, 47, 'SRUCSLIWM6', 'pending', '2017-12-26 05:55:57', '2017-12-26 05:55:57'),
(17, 48, 'GRICMD6FBF', 'pending', '2017-12-26 05:56:52', '2017-12-26 05:56:52'),
(18, 49, 'P0VZT7KHLY', 'pending', '2017-12-26 05:58:05', '2017-12-26 05:58:05'),
(19, 50, '2PV0PI1BVN', 'pending', '2017-12-26 12:44:17', '2017-12-26 12:44:17'),
(20, 51, 'MSWCGYKSNH', 'pending', '2017-12-27 10:13:38', '2017-12-27 10:13:38'),
(21, 52, 'UACSOPUPMK', 'pending', '2017-12-27 10:27:48', '2017-12-27 10:27:48'),
(35, 66, 'PVUJWGRTFC', 'pending', '2018-01-02 11:00:45', '2018-01-02 11:00:45'),
(36, 67, '4ZH80IFXOV', 'pending', '2018-01-02 11:01:52', '2018-01-02 11:01:52'),
(38, 69, 'QLLOPKARI7', 'active', '2018-01-02 13:23:06', '2018-01-02 13:24:06'),
(44, 76, 'HSKVB291TO', 'pending', '2018-01-04 07:15:29', '2018-01-04 07:15:29'),
(45, 78, '3ODPSEKL38', 'active', '2018-01-09 10:39:03', '2018-01-09 10:43:15'),
(46, 79, 'FCOEZII9QF', 'active', '2018-01-09 10:40:21', '2018-01-09 12:18:09'),
(47, 80, 'WNDR9REHUE', 'pending', '2018-01-10 06:02:39', '2018-01-10 06:02:39'),
(48, 81, '8TZAW8PG4T', 'pending', '2018-01-10 16:29:54', '2018-01-10 16:29:54'),
(49, 82, 'EBJM9TGK1A', 'pending', '2018-01-10 16:31:48', '2018-01-10 16:31:48'),
(50, 83, 'NT6SCCMY2P', 'active', '2018-01-20 04:03:53', '2018-01-20 04:05:42'),
(51, 85, 'K62XOYFNMI', 'active', '2018-01-22 09:41:41', '2018-01-22 09:42:42'),
(52, 86, 'JU5AGTJODN', 'active', '2018-01-22 09:41:56', '2018-01-22 09:43:17'),
(53, 87, '94OFITIWGC', 'pending', '2018-01-22 10:06:16', '2018-01-22 10:06:16'),
(54, 88, 'XBFLY8DN3M', 'pending', '2018-01-22 10:07:12', '2018-01-22 10:07:12'),
(55, 89, 'CF6L4VJRYU', 'pending', '2018-01-22 10:08:51', '2018-01-22 10:08:51'),
(56, 91, 'XMYQTWBTAN', 'active', '2018-01-24 04:48:41', '2018-01-24 04:54:04'),
(57, 93, '6UHZVG9VDH', 'active', '2018-01-24 05:19:26', '2018-01-24 05:23:46'),
(58, 94, 'J1V96YZPRR', 'active', '2018-01-24 05:24:27', '2018-01-24 05:25:37'),
(59, 95, '8HIGWGLCG0', 'pending', '2018-01-24 05:37:22', '2018-01-24 05:37:22'),
(60, 97, 'D1UWOIXRBK', 'active', '2018-01-24 05:45:58', '2018-01-24 05:49:41'),
(61, 98, 'XJBDIXAXRQ', 'active', '2018-01-24 05:50:30', '2018-01-24 06:51:18'),
(62, 99, 'MTQUCXLKIN', 'pending', '2018-01-24 05:59:37', '2018-01-24 05:59:37'),
(63, 100, 'YIKINNXQEG', 'active', '2018-01-24 06:03:26', '2018-01-24 06:52:45'),
(64, 101, 'DTI6YIX8HN', 'pending', '2018-01-24 06:03:36', '2018-01-24 06:03:36'),
(65, 102, '3YLCAXAABQ', 'pending', '2018-01-24 06:28:07', '2018-01-24 06:28:07'),
(66, 103, 'REVE6ESJEO', 'pending', '2018-01-24 06:28:17', '2018-01-24 06:28:17'),
(67, 104, 'JPKYWK865D', 'pending', '2018-01-24 06:41:55', '2018-01-24 06:41:55'),
(68, 105, 'E33NKTBQBK', 'pending', '2018-01-24 06:42:00', '2018-01-24 06:42:00'),
(69, 106, 'MZDX48T65A', 'active', '2018-01-24 06:46:26', '2018-01-24 06:58:49'),
(70, 107, 'OVHWYU97PV', 'active', '2018-01-24 06:46:33', '2018-01-24 07:05:43'),
(71, 108, 'QJDBZ0HUA9', 'pending', '2018-01-24 08:45:49', '2018-01-24 08:45:49'),
(72, 109, 'XYCKL6HGR1', 'pending', '2018-01-24 08:49:42', '2018-01-24 08:49:42'),
(73, 110, 'RMSVQ9KML7', 'pending', '2018-01-24 08:51:27', '2018-01-24 08:51:27'),
(74, 111, 'NMN4QBFA2M', 'pending', '2018-01-24 08:52:51', '2018-01-24 08:52:51');

-- --------------------------------------------------------

--
-- Table structure for table `c_lessonplan`
--

CREATE TABLE IF NOT EXISTS `c_lessonplan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lessonname` varchar(255) NOT NULL,
  `class_id` int(10) NOT NULL,
  `teacher_id` int(10) NOT NULL,
  `date` date NOT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `upload_file` varchar(255) NOT NULL,
  `status` enum('Pending','Approved','Rejected','') NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `c_lessonplan`
--

INSERT INTO `c_lessonplan` (`id`, `lessonname`, `class_id`, `teacher_id`, `date`, `remarks`, `upload_file`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Lesson Plan', 13, 78, '2018-01-18', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'uploads/lesson/PDF-1515574447.pdf', 'Rejected', '2018-01-10 03:24:07', '2018-01-22 05:28:42'),
(2, 'Lesson Plan 2', 12, 78, '2018-01-27', 'This is testing description', 'uploads/lesson/XLSX-1515574607.xlsx', 'Pending', '2018-01-10 03:26:47', '2018-01-10 06:22:51'),
(3, 'Lesson Plan 3', 12, 78, '2018-01-20', 'For PDF file', 'uploads/lesson/PDF-1515574674.pdf', 'Approved', '2018-01-10 03:27:54', '2018-01-24 11:52:42'),
(4, 'New Lesson Plan', 13, 78, '2018-01-31', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'uploads/lesson/PDF-1516187851.pdf', 'Pending', '2018-01-17 05:47:31', '2018-01-17 05:47:31'),
(5, 'Pre Kindergarden 01', 13, 78, '2018-01-27', 'Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur?', 'uploads/lesson/PDF-1516785052.pdf', 'Pending', '2018-01-24 03:40:52', '2018-01-24 03:40:52'),
(6, 'lesson1', 12, 78, '2018-01-25', NULL, 'uploads/lesson/XLSX-1516785207.xlsx', 'Pending', '2018-01-24 03:43:27', '2018-01-24 03:43:27'),
(7, 'Rhymes', 16, 91, '2018-01-25', NULL, 'uploads/lesson/PDF-1516787413.pdf', 'Approved', '2018-01-24 04:20:13', '2018-01-24 04:24:31'),
(8, 'Counting', 16, 91, '2018-01-25', NULL, 'uploads/lesson/PDF-1516787597.pdf', 'Rejected', '2018-01-24 04:23:17', '2018-01-24 04:28:12');

-- --------------------------------------------------------

--
-- Table structure for table `c_letterhead`
--

CREATE TABLE IF NOT EXISTS `c_letterhead` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `principal_id` int(11) NOT NULL,
  `media` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `c_letterhead`
--

INSERT INTO `c_letterhead` (`id`, `principal_id`, `media`, `created_at`, `updated_at`) VALUES
(1, 91, '1516783459-1.jpg', '2018-01-24 03:12:19', '2018-01-24 03:14:19'),
(2, 92, '1516784169-270x178.jpg', '2018-01-24 03:26:09', '2018-01-24 03:26:09'),
(3, 96, '1516855627-thumb-350-886787.jpg', '2018-01-24 08:16:53', '2018-01-24 23:17:07'),
(4, 90, '1516802509-1.jpg', '2018-01-24 08:30:07', '2018-01-24 08:31:49'),
(5, 77, '1516804209-avatar04.png', '2018-01-24 09:00:09', '2018-01-24 09:00:09');

-- --------------------------------------------------------

--
-- Table structure for table `c_meal`
--

CREATE TABLE IF NOT EXISTS `c_meal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_meal_id` int(10) unsigned NOT NULL,
  `property_meal_id` int(10) unsigned NOT NULL,
  `std_id` int(10) unsigned NOT NULL,
  `teacher_id` int(10) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `amount` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `comment` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `meal_type_meal_id_foreign` (`type_meal_id`),
  KEY `meal_property_meal_id_foreign` (`property_meal_id`),
  KEY `meal_std_id_foreign` (`std_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `c_meal`
--

INSERT INTO `c_meal` (`id`, `type_meal_id`, `property_meal_id`, `std_id`, `teacher_id`, `date`, `time`, `amount`, `comment`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 24, 78, '2018-01-12', '20:30:00', '20', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. ', '2018-01-13 05:05:19', '2018-01-13 05:05:19'),
(2, 1, 2, 23, 78, '2018-01-12', '20:30:00', '20', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. ', '2018-01-13 05:05:19', '2018-01-13 05:05:19'),
(4, 1, 1, 23, 78, '2018-01-10', '07:00:00', '40', 'asdfghjkl', '2018-01-17 00:40:07', '2018-01-17 00:40:07');

-- --------------------------------------------------------

--
-- Table structure for table `c_migrations`
--

CREATE TABLE IF NOT EXISTS `c_migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=29 ;

--
-- Dumping data for table `c_migrations`
--

INSERT INTO `c_migrations` (`id`, `migration`, `batch`) VALUES
(1, '2017_12_11_091933_create_users_table', 1),
(2, '2017_12_12_045607_settings', 1),
(3, '2017_12_15_091027_email_template', 1),
(4, '2017_12_15_092604_c_parents', 1),
(5, '2017_12_15_093246_c_teachers', 1),
(6, '2017_12_15_095649_c_students', 1),
(7, '2017_12_15_102903_user_type', 1),
(8, '2017_12_15_103240_c_classroom', 1),
(9, '2017_12_15_112642_c_attendance', 1),
(10, '2017_12_15_112917_c_classroom_teacher', 1),
(11, '2017_12_15_113218_c_classroom_student', 1),
(12, '2017_12_15_113636_c_verification', 1),
(13, '2017_12_15_114155_c_gallery', 1),
(14, '2017_12_15_114201_c_notice', 1),
(15, '2017_12_15_115753_c_type_meal', 1),
(16, '2017_12_15_115806_c_property_meal', 1),
(17, '2017_12_15_115821_c_meal', 1),
(18, '2017_12_15_121031_c_nap', 1),
(19, '2017_12_15_121042_c_observation', 1),
(20, '2017_12_15_121135_c_bulletboard', 1),
(21, '2017_12_15_121158_c_activities', 1),
(22, '2017_12_15_121207_c_tagging', 1),
(23, '2017_12_15_121226_c_lesson_plan', 1),
(24, '2017_12_15_121235_c_potty', 1),
(25, '2017_12_15_125417_static_content', 1),
(26, '2017_12_15_130132_static_content_home', 1),
(27, '2017_12_15_130137_static_content_home2', 1),
(28, '2017_12_20_093057_c_invitation_code', 1);

-- --------------------------------------------------------

--
-- Table structure for table `c_nap`
--

CREATE TABLE IF NOT EXISTS `c_nap` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `std_id` int(10) NOT NULL,
  `teacher_id` int(10) NOT NULL,
  `start_nap` timestamp NULL DEFAULT NULL,
  `end_nap` timestamp NULL DEFAULT NULL,
  `start_comment` text,
  `end_comment` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `c_nap`
--

INSERT INTO `c_nap` (`id`, `std_id`, `teacher_id`, `start_nap`, `end_nap`, `start_comment`, `end_comment`, `created_at`, `updated_at`) VALUES
(1, 24, 78, '2018-01-13 15:00:00', '2018-01-18 04:29:47', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.', '', '2018-01-13 06:53:42', '2018-01-18 04:29:47'),
(2, 23, 78, '2018-01-13 15:00:00', NULL, 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.', '', '2018-01-13 06:53:42', '2018-01-13 06:53:42'),
(3, 24, 78, '2018-01-10 13:30:00', NULL, 'zxcvbnm,', NULL, '2018-01-20 00:29:10', '2018-01-20 00:29:10');

-- --------------------------------------------------------

--
-- Table structure for table `c_notice`
--

CREATE TABLE IF NOT EXISTS `c_notice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `std_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notice_std_id_foreign` (`std_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `c_observation`
--

CREATE TABLE IF NOT EXISTS `c_observation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `std_id` int(10) unsigned NOT NULL,
  `teacher_id` int(10) unsigned NOT NULL,
  `category` enum('other','growth') COLLATE utf8_unicode_ci NOT NULL,
  `height` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `weight` decimal(10,0) NOT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8_unicode_ci NOT NULL,
  `approved` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `observation_std_id_foreign` (`std_id`),
  KEY `observation_teacher_id_foreign` (`teacher_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

--
-- Dumping data for table `c_observation`
--

INSERT INTO `c_observation` (`id`, `std_id`, `teacher_id`, `category`, `height`, `weight`, `comment`, `status`, `approved`, `created_at`, `updated_at`) VALUES
(2, 24, 78, 'other', '3''4', '20', '', 'rejected', 'no', '2018-01-10 11:32:13', '2018-01-24 06:04:28'),
(3, 23, 78, 'growth', '3''2', '19', 'belongsTo method specifying your parent table''s custom key.', 'rejected', 'no', '2018-01-10 11:34:14', '2018-01-24 06:12:43'),
(4, 23, 78, 'growth', '3''4', '21', 'Adding Observation', 'approved', 'no', '2018-01-10 11:39:02', '2018-01-24 06:17:39'),
(5, 23, 78, 'other', '', '0', 'We will use anonymous functions in the routes file', 'rejected', 'no', '2018-01-12 12:07:15', '2018-01-24 06:59:03'),
(6, 24, 78, 'growth', '3''2', '18', '', 'approved', 'no', '2018-01-12 12:07:41', '2018-01-24 06:04:48'),
(7, 23, 78, 'other', '', '0', 'My name is Khan Chintu Khan', 'approved', 'no', '2018-01-20 05:16:05', '2018-01-24 08:06:37'),
(8, 31, 93, 'other', '', '0', 'simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'pending', 'no', '2018-01-24 04:05:27', '2018-01-24 07:39:32'),
(9, 31, 92, 'other', '5', '56', '', 'rejected', 'no', '2018-01-24 04:44:22', '2018-01-24 07:42:55'),
(10, 33, 93, 'other', '', '0', 'test is done', 'approved', 'no', '2018-01-24 05:05:12', '2018-01-24 06:02:15'),
(11, 28, 91, 'other', '', '0', 'ghjhkjkbnn', 'approved', 'no', '2018-01-24 05:16:12', '2018-01-24 07:13:57'),
(12, 32, 93, 'other', '', '0', 'sdvfb nvdfvdfv', 'rejected', 'no', '2018-01-24 06:03:03', '2018-01-24 07:41:02'),
(13, 23, 78, 'other', '', '0', 'hgjh', 'pending', 'no', '2018-01-24 06:05:50', '2018-01-24 06:05:50'),
(14, 23, 78, 'other', '', '0', 'sacdsvfdgf', 'pending', 'no', '2018-01-24 06:09:38', '2018-01-24 06:09:38'),
(15, 23, 78, 'other', '', '0', 'sdsfd', 'pending', 'no', '2018-01-24 06:11:27', '2018-01-24 06:11:27'),
(16, 33, 93, 'other', '9', '908', '', 'pending', 'no', '2018-01-24 06:28:40', '2018-01-24 06:28:40'),
(17, 32, 93, 'other', '', '0', 'csd', 'pending', 'no', '2018-01-24 06:29:22', '2018-01-24 06:29:22'),
(18, 23, 78, 'other', '', '0', 'This is added on 24th Jan 2018 at 5:50 PM', 'pending', 'no', '2018-01-24 06:50:36', '2018-01-24 06:50:36'),
(19, 29, 91, 'other', '5.5', '4', '', 'rejected', 'no', '2018-01-24 07:17:30', '2018-01-24 07:18:26'),
(20, 28, 91, 'other', '', '0', 'Testing', 'approved', 'no', '2018-01-24 07:52:24', '2018-01-24 07:53:16'),
(22, 28, 91, 'other', '', '0', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'pending', 'no', '2018-01-24 23:10:42', '2018-01-24 23:10:42'),
(24, 23, 78, 'other', '2''4', '30', '', 'pending', 'no', '2018-01-24 23:14:40', '2018-01-24 23:14:40');

-- --------------------------------------------------------

--
-- Table structure for table `c_other`
--

CREATE TABLE IF NOT EXISTS `c_other` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `std_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `c_other`
--

INSERT INTO `c_other` (`id`, `std_id`, `teacher_id`, `comment`, `created_at`, `updated_at`) VALUES
(1, 24, 78, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', '2018-01-13 02:35:50', '2018-01-13 02:35:50'),
(2, 23, 78, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', '2018-01-13 02:35:50', '2018-01-13 02:35:50'),
(3, 24, 78, 'sdfghj', '2018-01-20 01:45:52', '2018-01-20 01:45:52');

-- --------------------------------------------------------

--
-- Table structure for table `c_parents`
--

CREATE TABLE IF NOT EXISTS `c_parents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parents_user_id_foreign` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=45 ;

--
-- Dumping data for table `c_parents`
--

INSERT INTO `c_parents` (`id`, `user_id`, `student_id`, `created_at`, `updated_at`) VALUES
(7, 35, 7, '2017-12-24 16:42:55', '2017-12-24 16:42:55'),
(8, 36, 7, '2017-12-24 16:43:02', '2017-12-24 16:43:02'),
(9, 37, 8, '2017-12-24 19:11:23', '2017-12-24 19:11:23'),
(10, 46, 9, '2017-12-25 18:51:33', '2017-12-25 18:51:33'),
(11, 47, 10, '2017-12-25 18:55:57', '2017-12-25 18:55:57'),
(12, 48, 11, '2017-12-25 18:56:52', '2017-12-25 18:56:52'),
(13, 49, 12, '2017-12-25 18:58:05', '2017-12-25 18:58:05'),
(14, 50, 13, '2017-12-26 01:44:17', '2017-12-26 01:44:17'),
(15, 51, 14, '2017-12-26 23:13:38', '2017-12-26 23:13:38'),
(19, 69, 21, '2018-01-02 02:23:06', '2018-01-02 02:23:06'),
(25, 76, 22, '2018-01-03 20:15:29', '2018-01-03 20:15:29'),
(26, 81, 23, '2018-01-10 10:59:54', '2018-01-10 10:59:54'),
(27, 82, 24, '2018-01-10 11:01:48', '2018-01-10 11:01:48'),
(28, 87, 25, '2018-01-22 04:36:15', '2018-01-22 04:36:15'),
(29, 88, 26, '2018-01-22 04:37:12', '2018-01-22 04:37:12'),
(30, 89, 27, '2018-01-22 04:38:51', '2018-01-22 04:38:51'),
(31, 97, 28, '2018-01-24 00:15:58', '2018-01-24 00:15:58'),
(32, 99, 29, '2018-01-24 00:29:37', '2018-01-24 00:29:37'),
(33, 100, 30, '2018-01-24 00:33:26', '2018-01-24 00:33:26'),
(34, 101, 30, '2018-01-24 00:33:36', '2018-01-24 00:33:36'),
(35, 102, 31, '2018-01-24 00:58:07', '2018-01-24 00:58:07'),
(36, 103, 31, '2018-01-24 00:58:17', '2018-01-24 00:58:17'),
(37, 104, 32, '2018-01-24 01:11:54', '2018-01-24 01:11:54'),
(38, 105, 32, '2018-01-24 01:12:00', '2018-01-24 01:12:00'),
(39, 106, 33, '2018-01-24 01:16:25', '2018-01-24 01:16:25'),
(40, 107, 33, '2018-01-24 01:16:33', '2018-01-24 01:16:33'),
(41, 108, 34, '2018-01-24 03:15:49', '2018-01-24 03:15:49'),
(42, 109, 35, '2018-01-24 03:19:42', '2018-01-24 03:19:42'),
(43, 110, 36, '2018-01-24 03:21:26', '2018-01-24 03:21:26'),
(44, 111, 37, '2018-01-24 03:22:51', '2018-01-24 03:22:51');

-- --------------------------------------------------------

--
-- Table structure for table `c_password_resets`
--

CREATE TABLE IF NOT EXISTS `c_password_resets` (
  `email` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `c_password_resets`
--

INSERT INTO `c_password_resets` (`email`, `token`, `created_at`) VALUES
('manishmahant@singsys.com', '$2y$10$RuKzKdn0Wd./CwX32OsgN.S.o7tLr8BVvo5PHnrPwy8ifG0535sMu', '2017-12-25 19:12:22'),
('chetandeep@singsys.com', '$2y$10$xt7ryy1dN7lEKBB04m/R3.WR5WaGGBHq.JG8fniDSiNBslD2jUkUy', '2017-12-27 03:43:27'),
('chetandeep+2@singsys.com', '$2y$10$lLoex1wDlfc4C/.P/2apQu1TAFZiNwIb.0m2kiN8BJNV4euloMBfC', '2018-01-01 22:04:41');

-- --------------------------------------------------------

--
-- Table structure for table `c_photos`
--

CREATE TABLE IF NOT EXISTS `c_photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `media` varchar(255) NOT NULL,
  `status` enum('draft','pending','approved','rejected') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `c_photos`
--

INSERT INTO `c_photos` (`id`, `teacher_id`, `title`, `media`, `status`, `created_at`, `updated_at`) VALUES
(1, 78, 'Title 1', '1516604187-blog-1.jpg', 'pending', '2018-01-22 01:26:27', '2018-01-22 01:26:58'),
(2, 78, 'Title 2', '1516604187-blog-2.jpg', 'approved', '2018-01-22 01:26:27', '2018-01-24 04:35:30'),
(3, 78, 'Title 3', '1516604187-blog-3.jpeg', 'approved', '2018-01-22 01:26:27', '2018-01-24 08:08:38'),
(4, 78, 'Title 4', '1516604187-blog-4.jpg', 'pending', '2018-01-22 01:26:27', '2018-01-22 01:26:59'),
(5, 78, 'Title 5', '1516604188-blog-5.jpg', 'pending', '2018-01-22 01:26:28', '2018-01-22 01:26:59');

-- --------------------------------------------------------

--
-- Table structure for table `c_photo_tagging`
--

CREATE TABLE IF NOT EXISTS `c_photo_tagging` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photo_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `c_potty`
--

CREATE TABLE IF NOT EXISTS `c_potty` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `std_id` int(10) unsigned NOT NULL,
  `teacher_id` int(10) NOT NULL,
  `content` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `wet` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL,
  `bowel` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `start_date` time NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `potty_std_id_foreign` (`std_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `c_potty`
--

INSERT INTO `c_potty` (`id`, `std_id`, `teacher_id`, `content`, `wet`, `bowel`, `start_date`, `created_at`, `updated_at`) VALUES
(1, 23, 78, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor i', 'no', 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '08:30:00', '2018-01-13 03:51:57', '2018-01-13 03:51:57'),
(2, 24, 78, 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'no', 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '09:00:00', '2018-01-13 03:53:01', '2018-01-13 03:53:01');

-- --------------------------------------------------------

--
-- Table structure for table `c_property_meal`
--

CREATE TABLE IF NOT EXISTS `c_property_meal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_meal_id` int(10) unsigned NOT NULL,
  `items` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `property_meal_type_meal_id_foreign` (`type_meal_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `c_property_meal`
--

INSERT INTO `c_property_meal` (`id`, `type_meal_id`, `items`, `created_at`, `updated_at`) VALUES
(1, 1, 'Milk', '2018-01-12 20:36:10', NULL),
(2, 1, 'Water', '2018-01-13 01:42:20', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `c_roles`
--

CREATE TABLE IF NOT EXISTS `c_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_type` enum('admin','principal','student','teacher','parent') COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `c_roles`
--

INSERT INTO `c_roles` (`id`, `user_type`, `created_at`, `updated_at`) VALUES
(1, 'admin', '2017-12-21 00:44:46', '2017-12-21 00:44:46'),
(2, 'principal', '2017-12-21 00:45:03', '2017-12-21 00:45:03'),
(3, 'teacher', '2017-12-21 22:41:39', '2017-12-21 22:41:39'),
(4, 'parent', '2017-12-21 22:42:57', '2017-12-21 22:42:57'),
(5, 'student', '2017-12-21 22:42:57', '2017-12-21 22:42:57');

-- --------------------------------------------------------

--
-- Table structure for table `c_staff_attendance`
--

CREATE TABLE IF NOT EXISTS `c_staff_attendance` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_staff` int(7) DEFAULT NULL,
  `attendance_status` enum('1','2','3') NOT NULL COMMENT ' 1=>present,2=>absent, 3=>signed out',
  `attendance_date` date DEFAULT NULL,
  `sign_in_time` time DEFAULT NULL,
  `sign_out_time` time DEFAULT NULL,
  `medical_certificate` enum('2','1') NOT NULL COMMENT '2=>submitted , 1=>not submitted',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_updated_by` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `c_staff_attendance`
--

INSERT INTO `c_staff_attendance` (`id`, `id_staff`, `attendance_status`, `attendance_date`, `sign_in_time`, `sign_out_time`, `medical_certificate`, `updated_at`, `last_updated_by`) VALUES
(1, 86, '2', '2018-01-22', '10:15:34', '10:17:18', '1', '2018-01-22 04:47:18', '84'),
(2, 85, '1', '2018-01-22', '10:15:34', NULL, '', '2018-01-22 10:15:34', '84'),
(3, 78, '1', '2018-01-23', '07:06:45', '11:11:11', '1', '2018-01-23 05:41:11', '77'),
(4, 79, '1', '2018-01-23', '11:04:45', '11:11:17', '1', '2018-01-23 05:41:17', '77'),
(5, 80, '1', '2018-01-23', '11:05:27', '11:11:15', '1', '2018-01-23 05:41:15', '77'),
(6, 78, '3', '2018-01-24', '05:06:02', '05:06:04', '1', '2018-01-23 23:36:04', '77');

-- --------------------------------------------------------

--
-- Table structure for table `c_static_content`
--

CREATE TABLE IF NOT EXISTS `c_static_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `c_static_content_home`
--

CREATE TABLE IF NOT EXISTS `c_static_content_home` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `heading` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `short_description` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `c_static_content_home`
--

INSERT INTO `c_static_content_home` (`id`, `description`, `heading`, `short_description`, `created_at`, `updated_at`) VALUES
(1, 'Chirppe is a school management web based application to enhance the school activities pertaining to students and keep the parents aware on the student’s activities and updates.', 'Bridge Gap between parents and their kids at school', 'Teachers at school easily note down observations around the day and use the application to:\r\nUpdate parents regarding child''s nap, meals and potty\r\nGet quick & easy consent from parents\r\nRecord child''s growth\r\nChat with parents\r\nGet reminders from parents\r\nShare photos and videos', '2017-12-04 11:23:53', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `c_static_content_home2`
--

CREATE TABLE IF NOT EXISTS `c_static_content_home2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `c_static_content_home2`
--

INSERT INTO `c_static_content_home2` (`id`, `image`, `description`, `created_at`, `updated_at`) VALUES
(1, 'crop_20171221040722.png', 'Mauris non tempor quam, et lacinia sapien.', '2017-12-04 11:23:53', NULL),
(2, 'crop_20171221040722.png', 'ccddccd', '2017-12-04 11:23:53', NULL),
(3, 'crop_20171221040722.png', 'cdcddcdcdc', '2017-12-04 11:23:53', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `c_students`
--

CREATE TABLE IF NOT EXISTS `c_students` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `profile_image` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `gender` enum('male','female') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'male',
  `date_of_birth` date DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `bloodtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `guardian1_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `guardian1_contact_no` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `relationship1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `guardian2_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `guardian2_contact_no` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `relationship2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `drugs_allergy` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `medical_condition` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `height` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weight` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `studentStatus` enum('0','1') COLLATE utf8_unicode_ci DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `appear_status` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '1=> saved, 0=>deleted',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=38 ;

--
-- Dumping data for table `c_students`
--

INSERT INTO `c_students` (`id`, `user_id`, `firstname`, `lastname`, `profile_image`, `gender`, `date_of_birth`, `address`, `postal_code`, `class_id`, `bloodtype`, `guardian1_name`, `guardian1_contact_no`, `relationship1`, `guardian2_name`, `guardian2_contact_no`, `relationship2`, `drugs_allergy`, `medical_condition`, `height`, `weight`, `studentStatus`, `created_at`, `updated_at`, `appear_status`) VALUES
(7, 25, 'ABD', 'ASD', '', 'male', '2017-12-04', 'dsda', '12345678', 1, 'B +ve', 'Man', '123456789', 'father', 'Mani', '987654321', 'mother', 'fcgvhjb,sadgfg', 'asdfg,asdfg', NULL, NULL, '1', '2017-12-24 16:42:55', '2017-12-24 16:42:55', '1'),
(8, 25, 'sfdghhfgds', 'asdfggdsf', '', 'male', '2017-12-04', 'dsfgb', '1234', 6, 'O +ve', 'aserdf', NULL, 'mother', NULL, NULL, NULL, 'fdg', 'szdf', NULL, NULL, '1', '2017-12-24 19:11:23', '2017-12-24 19:11:23', '1'),
(9, 25, 's1', NULL, '', 'male', '2009-04-13', 'jdrtsdhdcc', '1234', 1, NULL, 'g1', NULL, 'uncle', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '2017-12-25 18:51:33', '2017-12-25 18:51:33', '1'),
(10, 25, 's2', NULL, '', 'male', '2008-12-22', 'jdrtsdhdccsx', '1234', 1, NULL, 'g2', NULL, 'father', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '2017-12-25 18:55:56', '2017-12-25 18:55:56', '1'),
(11, 25, 's3', NULL, '', 'male', '2009-12-21', 'jdrtsdhdccss', '1234', 1, NULL, 'g3', NULL, 'mother', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '2017-12-25 18:56:52', '2017-12-25 18:56:52', '1'),
(12, 25, 's4', NULL, '', 'male', '2008-12-14', 'jdrtsdhdcc', '1234', 5, NULL, 'g4', NULL, 'uncle', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '2017-12-25 18:58:04', '2017-12-25 18:58:04', '1'),
(13, 2, 's5', NULL, '', 'male', '2017-12-12', 'jdrtsdh', '1234', 2, NULL, 'manish', NULL, 'father', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '2017-12-26 01:44:17', '2017-12-26 01:44:17', '1'),
(14, 2, 'Nadeem', 'Ahmed', 'uploads/user_profile/2_20180118043224.png', 'male', '2017-11-08', 'Street Building', '213112', 1, NULL, '21343322', NULL, 'father', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '2017-12-26 23:13:37', '2018-01-17 23:02:37', '1'),
(15, 2, 'scdsc', NULL, '', 'male', '2017-12-04', 'dcd', '13232', 1, NULL, 'saddas', NULL, 'mother', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '2017-12-26 23:27:48', '2017-12-26 23:27:48', '1'),
(20, 2, 'raveena', NULL, '', 'male', '2018-01-01', 'High Street Road', '12345', 1, NULL, 'manish', '123435676', 'uncle', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '2018-01-02 02:04:29', '2018-01-02 02:04:29', '1'),
(21, 2, 'sultan', NULL, '', 'male', '2018-01-01', 'High Street Road', '12345', 1, NULL, 'manish', '12345677', 'father', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '2018-01-02 02:23:06', '2018-01-02 02:23:06', '1'),
(22, 2, 'ssaasdds', NULL, '', 'male', '2017-12-05', 'jdrtsdh', '213112', 1, NULL, 'dsaadssd', 'father', 'sadasd', 'sdsd', '123', '132', '2', '2', '1', '2017-12-27 10:13:37', NULL, NULL, NULL, '1'),
(23, 77, 'Nadeem', 'Ahmed', '', 'male', '2018-01-01', 'sdfg', '789023', 13, 'A -ve', 'Akmal Ansari', '9876345678', 'father', NULL, NULL, NULL, 'cdvfbg', 'xasdvfbg', NULL, NULL, '1', '2018-01-10 10:59:54', '2018-01-24 03:16:54', '1'),
(24, 77, 'Kriti', 'Jaiswal', '', 'female', '2017-10-11', 'North Bridge, Buidling Block', '789023', 13, NULL, 'Devendra Shukla', '9876345678', 'father', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '2018-01-10 11:01:48', '2018-01-10 11:01:48', '1'),
(25, 84, 'Shivansh', 'Sir', '', 'male', '2018-01-01', 'High Street Road', '12345', 15, 'A -ve', 'FatherShivansh', '123456345', 'father', NULL, NULL, NULL, 'drugsss', 'mediaclaa', NULL, NULL, '1', '2018-01-22 04:36:15', '2018-01-22 04:36:15', '1'),
(26, 84, 'Abhinav', 'Saxena', '', 'female', '2017-07-11', 'North Bridge', '345234', 14, 'O +ve', 'Abhinav Parent', '8762345673', 'father', NULL, NULL, NULL, 'Paracetamol', 'Not Well', NULL, NULL, '1', '2018-01-22 04:37:12', '2018-01-22 04:37:12', '1'),
(27, 84, 'Preeti', 'Singh', '', 'female', '2018-01-17', 'North Bridge', '345678', 14, NULL, 'Preeti Parent', '345698765', 'mother', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '2018-01-22 04:38:50', '2018-01-22 04:38:50', '1'),
(28, 90, 'Child', '1', '', 'male', '2018-01-23', 'omaxe', '234567', 16, 'B -ve', 'father', '5647893210', 'father', NULL, NULL, NULL, '234567', 'test', NULL, NULL, '1', '2018-01-24 00:15:57', '2018-01-24 22:20:26', '1'),
(29, 90, 'Child', '2', '', 'female', '2018-01-24', 'omaxe', '345676', 21, NULL, 'Mother', '7896541230', 'mother', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '2018-01-24 00:29:36', '2018-01-24 00:29:36', '1'),
(31, 92, 'ANKIT', 'Student', '', 'male', '2018-01-09', '12, hazrat ganj Lucknow', '226001', 27, 'B -ve', 'Chanchal', '123456987', 'mother', 'Reena', '123654789', 'aunty', '226001', 'no', NULL, NULL, '1', '2018-01-24 00:58:06', '2018-01-24 03:58:00', '1'),
(32, 92, 'durgesh', 'student', '', 'male', '2015-07-15', 'omaxe', '226001', 29, 'B +ve', 'durgesh', '12345678', 'father', 'abhishek', '12345678', 'uncle', NULL, NULL, NULL, NULL, '1', '2018-01-24 01:11:54', '2018-01-24 01:11:54', '1'),
(33, 92, 'shubham', 'student', '', 'male', '2018-01-09', 'omaxe', '226018', 32, 'A -ve', 'akash', '12365478', 'father', 'kumar', '123654789', 'uncle', NULL, NULL, NULL, NULL, '1', '2018-01-24 01:16:25', '2018-01-24 01:16:25', '1'),
(34, 96, 'Amit', 'stu', '', 'male', '2012-10-17', 'triveni nagar 3 sitapur road lko', '226020', 38, 'B +ve', 'r.d', '12345678', 'father', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '2018-01-24 03:15:49', '2018-01-24 03:15:49', '1'),
(35, 96, 'Pooja', 'Stu', '', 'female', '2012-05-09', 'triveni nagar  sitapur road lko', '226020', 38, 'A +ve', 'p.l', '9839801647', 'father', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '2018-01-24 03:19:42', '2018-01-24 03:19:42', '1'),
(36, 96, 'dev', 'Stu', '', 'male', '2012-05-09', 'triveni nagar  sitapur road lko', '226020', 38, NULL, 'r.k', '9839801645', 'father', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '2018-01-24 03:21:26', '2018-01-24 03:21:26', '1'),
(37, 96, 'rash', 'stu', '', 'female', '2012-05-12', 'triveni nagar  sitapur road lko', '226020', 38, 'O +ve', 'r.d', '9839801689', 'father', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '2018-01-24 03:22:51', '2018-01-24 03:22:51', '1');

-- --------------------------------------------------------

--
-- Table structure for table `c_student_attendance`
--

CREATE TABLE IF NOT EXISTS `c_student_attendance` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_student` int(7) DEFAULT NULL,
  `attendance_status` enum('1','2','3') NOT NULL DEFAULT '2' COMMENT '2=>absent, 1=>present,3 =>signedOut',
  `attendance_date` date DEFAULT NULL,
  `sign_in_time` time DEFAULT NULL,
  `sign_out_time` time DEFAULT NULL,
  `daily_health` varchar(255) DEFAULT NULL,
  `body_temprature` float DEFAULT NULL,
  `medical_certificate` enum('1','2') DEFAULT '2' COMMENT '2=> "Not Submitted", 1=>"Submitted"',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `c_student_attendance`
--

INSERT INTO `c_student_attendance` (`id`, `id_student`, `attendance_status`, `attendance_date`, `sign_in_time`, `sign_out_time`, `daily_health`, `body_temprature`, `medical_certificate`, `updated_at`, `last_updated_by`) VALUES
(1, 26, '1', '2018-01-22', NULL, NULL, NULL, NULL, '2', '2018-01-22 10:18:46', '84'),
(2, 24, '1', '2018-01-23', '09:00:00', NULL, 'blisters,ulcer', 98, '2', '2018-01-23 11:06:38', '77'),
(3, 24, '1', '2018-01-23', '09:00:00', NULL, 'sore-eyes,ulcer', 98, '2', '2018-01-23 12:46:13', '77'),
(4, 24, '1', '2018-01-23', '04:58:00', NULL, 'blisters,sore-eyes', 67, '2', '2018-01-23 12:47:21', '77'),
(5, 24, '2', '2018-01-23', NULL, NULL, NULL, NULL, '1', '2018-01-23 12:47:37', '77');

-- --------------------------------------------------------

--
-- Table structure for table `c_tagging`
--

CREATE TABLE IF NOT EXISTS `c_tagging` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `std_id` int(10) unsigned NOT NULL,
  `parent_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tagging_std_id_foreign` (`std_id`),
  KEY `tagging_parent_id_foreign` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `c_teachers`
--

CREATE TABLE IF NOT EXISTS `c_teachers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `principal_id` int(11) DEFAULT NULL,
  `gender` enum('male','female') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'male',
  `date_of_birth` date DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `teacherStatus` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `teachers_user_id_foreign` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=33 ;

--
-- Dumping data for table `c_teachers`
--

INSERT INTO `c_teachers` (`id`, `user_id`, `principal_id`, `gender`, `date_of_birth`, `address`, `postal_code`, `teacherStatus`, `created_at`, `updated_at`) VALUES
(4, 42, 25, 'male', NULL, NULL, NULL, '1', '2017-12-25 06:19:30', '2017-12-25 06:19:30'),
(5, 43, 25, 'male', NULL, NULL, NULL, '1', '2017-12-25 11:34:21', '2017-12-25 11:34:21'),
(6, 44, 25, 'male', NULL, NULL, NULL, '1', '2017-12-25 18:38:57', '2017-12-25 18:38:57'),
(7, 45, 25, 'male', NULL, NULL, NULL, '1', '2017-12-25 18:41:44', '2017-12-25 18:41:44'),
(20, 66, 2, 'male', NULL, NULL, NULL, '1', '2018-01-02 00:00:44', '2018-01-02 00:00:44'),
(21, 67, 2, 'male', NULL, NULL, NULL, '1', '2018-01-02 00:01:52', '2018-01-02 00:01:52'),
(22, 78, 77, 'male', NULL, NULL, NULL, '1', '2018-01-09 05:09:03', '2018-01-09 05:09:03'),
(23, 79, 77, 'male', NULL, NULL, NULL, '1', '2018-01-09 05:10:21', '2018-01-09 05:10:21'),
(24, 80, 77, 'male', NULL, NULL, NULL, '1', '2018-01-10 00:32:39', '2018-01-10 00:32:39'),
(25, 83, 2, 'male', NULL, NULL, NULL, '1', '2018-01-19 22:33:53', '2018-01-19 22:33:53'),
(26, 85, 84, 'male', NULL, NULL, NULL, '1', '2018-01-22 04:11:41', '2018-01-22 04:11:41'),
(27, 86, 84, 'male', NULL, NULL, NULL, '1', '2018-01-22 04:11:56', '2018-01-22 04:11:56'),
(28, 91, 90, 'male', NULL, NULL, NULL, '1', '2018-01-23 23:18:41', '2018-01-23 23:18:41'),
(29, 93, 92, 'male', NULL, NULL, NULL, '1', '2018-01-23 23:49:26', '2018-01-23 23:49:26'),
(30, 94, 77, 'male', NULL, NULL, NULL, '1', '2018-01-23 23:54:27', '2018-01-23 23:54:27'),
(31, 95, 77, 'male', NULL, NULL, NULL, '1', '2018-01-24 00:07:22', '2018-01-24 00:07:22'),
(32, 98, 96, 'male', NULL, NULL, NULL, '1', '2018-01-24 00:20:30', '2018-01-24 00:20:30');

-- --------------------------------------------------------

--
-- Table structure for table `c_type_meal`
--

CREATE TABLE IF NOT EXISTS `c_type_meal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('solid','liquid') COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `c_type_meal`
--

INSERT INTO `c_type_meal` (`id`, `type`, `created_at`, `updated_at`) VALUES
(1, 'liquid', NULL, NULL),
(2, 'solid', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `c_users`
--

CREATE TABLE IF NOT EXISTS `c_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_no` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` enum('male','female') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'male',
  `date_of_birth` date DEFAULT NULL,
  `profile_image` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `api_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userStatus` enum('0','1') COLLATE utf8_unicode_ci DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `api_token` (`api_token`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=112 ;

--
-- Dumping data for table `c_users`
--

INSERT INTO `c_users` (`id`, `firstname`, `lastname`, `email`, `password`, `address`, `mobile_no`, `gender`, `date_of_birth`, `profile_image`, `api_token`, `remember_token`, `userStatus`, `created_at`, `updated_at`) VALUES
(1, 'Chirppe Admin', '', 'info@chirppe.com', '$2y$10$LcUUZ6Qduw53OWqpKl9gDOKBeuoiigoMaPquSH9s6QYPS2cPllkFC', NULL, '', 'male', NULL, 'uploads/admins/_20180124051718.png', NULL, 'mxLUJRmcD2qPIFU9l5ho0iNYqG7lLrDQfNX3s50qCpWF3kEIGaScqxCuHxFX', '1', '2017-12-04 11:23:53', '2018-01-23 23:47:18'),
(2, 'Chetan', 'Deep', 'chetandeep@singsys.com', '$2y$10$m7OixRbU1cOn39Mk0YlEMeM9NWzrA7tGoysQNoRNYhid1kIDgtZpa', 'High Street Road', '123456789', 'male', '2018-01-01', NULL, 'eDJZNc9d78Cl93K85NgOttXv0P0PblTYJDoCBsrGuZiBA7IagxdoRNrLRcgv', 'sXqkZPvLKlEJCRrzl2s0MP3C3GZFsn7zHDPa8IbzOvvFWaIj8C9yNG10Cs0v', '1', '2017-12-04 11:23:53', '2018-01-19 22:39:12'),
(25, 'Emily1', 'Parker1', 'manishmahant@singsys.com', '$2y$10$KseU99NrlYJLJcPaNTG5q.FydF1LdFFe9iETBg1cpxRKyem6sqe.e', NULL, '89521456', 'male', NULL, 'uploads/admins/20171223044931.png', NULL, 'wo4ZXkgrPDT9nRVuRQr1BEz43DCYxlCuLWZ2OJGsEUwatyoJS7fq6XRd7yNW', '1', '2017-12-22 12:33:35', '2017-12-25 19:47:44'),
(26, 'Chetan', 'Deep Singh', 'chetandeep+1@singsys.com', '$2y$10$9wvg8mJFswk0diTAxYcz..FuRRE5/QD62lSOduejFefR2X8DRCBp.', NULL, '123456543', 'male', NULL, 'uploads/admins/20171223044931.png', NULL, NULL, '1', '2017-12-22 16:07:03', '2017-12-22 16:07:03'),
(27, 'Chetan', 'Deep Singh', 'chetandeep+2@singsys.com', '$2y$10$d4DMHEyA/RfpkZGXwUnpRechR2/w9MBxcuKn5WdtvrWsKBTFSxFLe', NULL, '1234567890', 'male', NULL, NULL, NULL, NULL, '1', '2017-12-22 22:09:24', '2017-12-22 22:09:24'),
(35, 'Man', NULL, 'manishmahant+1@singsys.com', '$2y$10$KseU99NrlYJLJcPaNTG5q.FydF1LdFFe9iETBg1cpxRKyem6sqe.e', NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2017-12-24 16:42:55', '2017-12-24 16:42:55'),
(36, 'Manish', 'Mahant', 'manishmahant+2@singsys.com', '$2y$10$jbDq2rvBCdJeL8n8rZK3JuWuIdoMqiO2rRxcd0EcM26BaeSeBnJWe', NULL, '125678975', 'male', NULL, NULL, NULL, 'GJLbJ893dWx3X1qeQ2cxh7A19URYaJHWqhqVPzPmTdOTSPSYkaz4kuklYd6i', '1', '2017-12-24 16:43:02', '2017-12-24 16:46:22'),
(37, 'aserdf', NULL, 'manishmahant+6@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2017-12-24 19:11:23', '2017-12-24 19:11:23'),
(42, 'Manish', 'fxfchgvjh', 'manishmahant+1111@singsys.com', '$2y$10$.K4pU0CwmjU7QVas0UWLYOSsWOot6HWzWCeRaXaYX1V5OlpUKWlYK', NULL, '123456237', 'male', NULL, NULL, NULL, NULL, '1', '2017-12-25 06:19:30', '2017-12-25 06:21:09'),
(43, 'Manish 1', 'Mahant', 'manishmahant+111@singsys.com', '$2y$10$VbmrVGiEZYgyqyA4OXOAEe/sta0TFs.nvFY1lp9ARbkPRGNC/HOvm', NULL, '234534567', 'male', NULL, NULL, NULL, 'q6xbQOhu9j8VOGnDvDax922tISZjoNUUg1NMyDbGC9HO8cvkPSew6Jo03q87', '1', '2017-12-25 11:34:21', '2017-12-25 11:35:12'),
(44, 'staff1', 'staff2', 'chetandeep+5@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2017-12-25 18:38:57', '2017-12-25 18:38:57'),
(45, 'staff22', NULL, 'chetandeep+6@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2017-12-25 18:41:44', '2017-12-25 18:41:44'),
(46, 'g1', NULL, 'chetandeep+9@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2017-12-25 18:51:33', '2017-12-25 18:51:33'),
(47, 'g2', NULL, 'chetandeep+34@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2017-12-25 18:55:57', '2017-12-25 18:55:57'),
(48, 'g3', NULL, 'chetandeep+34@singsys.co5', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2017-12-25 18:56:52', '2017-12-25 18:56:52'),
(49, 'g4', NULL, 'chetandeep+19@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2017-12-25 18:58:04', '2017-12-25 18:58:04'),
(50, 'manish', NULL, 'chetandeep+16@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2017-12-26 01:44:17', '2017-12-26 01:44:17'),
(51, '213', NULL, 'chetandeep+13@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2017-12-26 23:13:38', '2017-12-26 23:13:38'),
(52, 'saddas', NULL, 'chetandeep+213@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2017-12-26 23:27:48', '2017-12-26 23:27:48'),
(66, 'staff123', NULL, 'chetandeep+90@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2018-01-02 00:00:44', '2018-01-02 00:00:44'),
(67, 'staff321', NULL, 'chetandeep+89@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2018-01-02 00:01:52', '2018-01-02 00:01:52'),
(69, 'sultan jr', 'junior', 'chetandeep+78@singsys.com', '$2y$10$F5WTjAEeF9n3nrB.FIUoK.kQXUvJl2hNao2TKlKmwAor491XaGHMe', 'High Street Road 222222', '1234567', 'male', NULL, NULL, NULL, 'FKfKQmZZ5zcdY86TZKC6QfY6sR9y0N1OEWnmp1OE1EUj0WWPTNIav5UOQM40', '1', '2018-01-02 02:23:06', '2018-01-03 17:17:43'),
(76, 'ssaasdds', NULL, 'chetandeep+77@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2018-01-03 20:15:28', '2018-01-03 20:15:28'),
(77, 'Raveena', 'Nigam', 'raveena+principal@singsys.com', '$2y$10$aE/0vee3s7WI88jKSiOzVOIPeKMlCdDXP/tMnIc.XKb.883DD3v3O', 'North Bridge', '98763456788', 'female', '2018-01-10', NULL, '1SJIN1zcDF1mSxy3qFmelwBcCNko6z9c63whKrakqiywj3XW7D0Qcp1Y7vKW', 'IFy6lYaS6YLHu9KBCZRImEQMWgoJgOGvkTWeaAoLye9gwdZTD6gx2DHUdZin', '1', '2018-01-09 04:57:47', '2018-01-21 23:15:43'),
(78, 'Aatif', 'Nehal', 'aatif+teacher@singsys.com', '$2y$10$Y9S5T0icK2NQYfXzybTzluVxQL6b3B5fsMIc3sRKjkW9JxsjinMw2', 'North Bridge, Singapore - 227890', '98765123456', 'male', '2018-01-11', NULL, 'CBnOKuG7nTTkbCLFxxQP1acW9qOeLt6b3Ix6C6Yr6IA9gsgW7bGa1YqSAkei', 'LlZqscUC0Mmz9PGXhChZ8XKFZQrjDpnOxYFZBvA1HQmptS81Fhb8l9FZGXj7', '1', '2018-01-09 05:09:03', '2018-01-24 01:25:36'),
(79, 'Rahul Pratap', 'Singh Chauhan', 'rahulpratap@singsys.com', '$2y$10$lBHii7ll5Vet7IzP8KTDiuEiM5yaKQJSLVvLK.6vAgkPCqPI.VFD6', NULL, '987652345', 'male', NULL, NULL, NULL, NULL, '1', '2018-01-09 05:10:21', '2018-01-09 06:48:09'),
(80, 'Chetan', 'Deep', 'chetandeep+teacher@singsys.com', NULL, NULL, '934567823', 'male', NULL, NULL, NULL, NULL, '0', '2018-01-10 00:32:39', '2018-01-10 00:32:39'),
(81, 'Akmal Ansari', NULL, 'akmal@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2018-01-10 10:59:54', '2018-01-10 10:59:54'),
(82, 'Devendra Shukla', NULL, 'devendra@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2018-01-10 11:01:48', '2018-01-10 11:01:48'),
(83, 'Manish', 'Mahant', 'manishmahant+1000@singsys.com', '$2y$10$LcUUZ6Qduw53OWqpKl9gDOKBeuoiigoMaPquSH9s6QYPS2cPllkFC', NULL, '765456765678', 'male', NULL, NULL, 'LnRPKFtusRGqJ5vZsnxGnoxPMGUGxULPnp0I621aQfXwsdLaRa64GWmTqitu', 'HcktIVWVBSzjGAMNQDaLBZIvYzYvcLJv4mB7ovL9jmLz7GAe7EWG2pIvtVxa', '1', '2018-01-19 22:33:53', '2018-01-19 22:35:43'),
(84, 'Piyoosh', 'Shukla', 'piyoosh@singsys.com', '$2y$10$NitnqzMBP2bw0Y30VS.geOZ.SBnb8JgHqzcKA6NoCVd3uxDuhGSBe', NULL, '9876523456', 'male', NULL, NULL, '8edEcBHCLqvHISk4t8hq4YgBciXrNvsDtaHJ2u7H279sF8NeahZvbIllE2lK', 'cPgj2hOdFLlci6f2on0SrxUWO8LWCmDfDJSqFGGNBWOFy6nNq5gcOYNqfA7w', '1', '2018-01-22 04:09:37', '2018-01-22 04:09:37'),
(85, 'Saurabh', 'Shukla', 'raveena+1@singsys.com', '$2y$10$HM9wbKDeNPGtYhCxZVlWR.TJGYkRN91qdBfLq8Vk6FlQhr0uw0Uca', NULL, '98765432345', 'male', NULL, NULL, '1E2RDBsQ3B13VmVbi6Qh3CoCVEiGZ71nsSMoMDYQwbnXOJt3Q5zRYLtw78xb', NULL, '1', '2018-01-22 04:11:41', '2018-01-22 04:12:42'),
(86, 'Gaurav', 'Jaiswal', 'chetandeep+gaurav@singsys.com', '$2y$10$kLvUSOKIxxoEsysguCdnHO.cucpe7FCm.IhcJNQ8IBYuV0F72BJQq', NULL, '12345679', 'male', NULL, NULL, 'm2V7CVKd6r9ABCYQ63POVOlyq2vfNtohketfnohPaUrrUv4QyofOPBBbE4I0', NULL, '1', '2018-01-22 04:11:56', '2018-01-22 04:13:17'),
(87, 'FatherShivansh', NULL, 'chetandeep+shivansh@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2018-01-22 04:36:15', '2018-01-22 04:36:15'),
(88, 'Abhinav Parent', NULL, 'raveena+2@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2018-01-22 04:37:12', '2018-01-22 04:37:12'),
(89, 'Preeti Parent', NULL, 'raveena+3@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2018-01-22 04:38:50', '2018-01-22 04:38:50'),
(90, 'Chanchal', 'Principal', 'chanchal+p@singsys.com', '$2y$10$7UT6GkmuFkyhspCJj6Y4euA.Zt9gVz8hDuEIaM.YpIZQjXvVt1Y.e', NULL, '8796541230', 'male', NULL, NULL, 'wYfuwCZTfCTpdgw8IMCPgMmzkWZlcyaRWBde06V9sM9nbxD325gt3t2qp9qv', '4p56X6VpqyDw1LVytmaFcttaGxebIrVZgHKqaj9UnYyuKZg1aytykyZYv02s', '1', '2018-01-23 23:14:13', '2018-01-23 23:14:13'),
(91, 'Chanchal', 'Teacher', 'chanchal+T@singsys.com', '$2y$10$af12MaEmp6XaJNpSzUfO4OQywrM5NSnQLzHATLhSd033mf6rU34pm', NULL, '8765385914', 'male', NULL, NULL, 'U0oVzZHpsG3baFCU2wj9VW0kMwSswz5d66v5diNe2P90uwkpiwIfekuTKKL3', 'ZGe78PHlIq4YWogcsBYwV09zYojX2B5XcSv8HiKqIHCBvDgw9NV0nEEyrWtt', '1', '2018-01-23 23:18:41', '2018-01-23 23:24:04'),
(92, 'Ankit principle', 'Jaiswal', 'ankitjaiswal+principle@singsys.com', '$2y$10$3kzIxb0WEiom.fXIt9Lx7.WXtHuPE4UdQK3n8YU9af6KMD9lbbpyy', 'omaxe', '12345678', 'male', '2009-06-17', NULL, 'gXAYjUhcdMKhT4nQTA5mfOmkiMt7NoCefauAp06DoCvLCg3E9NjwtuTWb2C2', 'Tpi80Tx7NKGj2HJXE9561xEWHkNtbH3KLnJbcnOwqn80ZRuuPnhTVa60bnFI', '1', '2018-01-23 23:36:50', '2018-01-23 23:43:05'),
(93, 'Ankit Teacher', 'Jaiswal', 'ankitjaiswal+teacher@singsys.com', '$2y$10$LxpFV7ORsZZ9nW4P7k5z6OdOoH9zsi1NHzgBi0OnQDDEL6BxaRKgu', NULL, '654123987', 'male', NULL, NULL, 'q9nG9tU3SO2ymYLwhwMkT7ZlfJzsXqhCql0ofZtSaM460h0uQ2GgHtkKTTeg', 'zZAFs52XzJ1NCPU7QMOCz5GFkfzthMCrkjd7lbnKBNJRPQLpjsFEBOuEQwvJ', '1', '2018-01-23 23:49:26', '2018-01-23 23:53:47'),
(94, 'piyooshteacher', 'ttttpiyoosh', 'chetandeep+piyoosh@singsys.com', '$2y$10$6XsTzixdToIRRIoxa4ECxOEmHMZ8RXuBsJTUR/UrRHlUqYw7lRmt6', NULL, '123456785', 'male', NULL, NULL, '7ERUJvxeQFt6Ua1rIRkMFWTC9S5j88GpfLFgsnmlmObiEXfHKdM9alJg4b32', 'vKo4jeL8rfZSxdYZBooVM93ZjzuJcViOyaqqVfJKeN9tBaMSMjTc9UcJtNcl', '1', '2018-01-23 23:54:27', '2018-01-23 23:55:37'),
(95, 'shubhamteacher', 'sir', 'chetandeep+shubham@singsys.com', NULL, NULL, '123443243', 'male', NULL, NULL, NULL, NULL, '0', '2018-01-24 00:07:22', '2018-01-24 00:07:22'),
(96, 'durgesh', 'principle', 'durgesh@singsys.com', '$2y$10$i7xCpR3ks6yv63DanQTdNuA9NFZvUhs.wRPLducfqdaFOBL2oalI6', NULL, '7607934871', 'male', NULL, NULL, '9H2UK4cP85QGJaOQVXbocTz0ojz3AMNAVpBJtmbha6EMl9n9A8VBFhdlTepz', 'Xocp4L5KFLu3VoqGPctW9gpkOyqPOlGAOUl7KbG6FzpVJZ3iLL1UlSPLLzU7', '1', '2018-01-24 00:09:17', '2018-01-24 00:09:17'),
(97, 'father', 'Parents', 'chanchal+f@singsys.com', '$2y$10$amJwj8u341MWEhEjZ29YZ.HPImdOuV2KG6L3qkILLA9KxNTQPxHSy', NULL, '5896471230', 'male', NULL, NULL, '1XVGPX7JhAAmPXWFF2ii408RXEXp6sInqgImIFlpNT5aTNVTtHHk199i78Bd', 'Dp6lEae64LxCzg3c7jx1tPiL0lAK8BVTxgWILzuu765l93BtevzOrAkMEeq7', '1', '2018-01-24 00:15:58', '2018-01-24 00:19:41'),
(98, 'Hema', 'teacher', 'durgesh+1@singsys.com', '$2y$10$8Wn01VW2itgZQUBnOuNguujJvILfMjhm26TNsvE/zWS9UoyIgxPxa', NULL, '7607934872', 'male', NULL, NULL, 'XnE8BkgFL39Sp8Vynqzk4y6GOipo5TonYXWLyELYFhQmXR1x78XSOg0x48GH', 'ssyVhxodra4G0TgzgwxCwEpN5uCTGuHZCpbbYyUpvDRHGpwyGfp913jYn50k', '1', '2018-01-24 00:20:30', '2018-01-24 01:21:18'),
(99, 'Mother', NULL, 'chanchal+m@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2018-01-24 00:29:37', '2018-01-24 00:29:37'),
(100, 'Reena', 'kumari', 'ankitjaiswal+student@singsys.com', '$2y$10$0W64gbQgS64.JTvey7DJlevvfusaiwWGEuV2ylN16SVSAUHRrJdKK', NULL, '123658789', 'male', NULL, NULL, 'wZu2T4QqYbRX3TKsVeiwWthWtjpfTX9su4JewveQGLpkAhFUGaHord4xawx3', '0DnyOJ3gqb3kFHHdzl6C6iKLtmvdFcYycZFZawrDCnZJ9jk9dXoRFWMy2Dhw', '1', '2018-01-24 00:33:26', '2018-01-24 01:22:45'),
(101, 'Chanchal', NULL, 'ankitjaiswal+student1@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2018-01-24 00:33:36', '2018-01-24 00:33:36'),
(102, 'Chanchal', NULL, 'ankitjaiswal+student2@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2018-01-24 00:58:06', '2018-01-24 00:58:06'),
(103, 'Reena', NULL, 'ankitjaiswal+student3@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2018-01-24 00:58:17', '2018-01-24 00:58:17'),
(104, 'durgesh', NULL, 'durgesh+2@singsys.com', '$2y$10$xtYjzmbD6ZKnrEFbao8TJOi.ndyWaFSWcSFKEQg7RkW/2yZedz5Y2', NULL, NULL, 'male', NULL, NULL, NULL, 'p0miccHX8b0FSYIyI61wZKoitiXvZK1OkAmBElHC293ikeusMoknAmeQpe29', '0', '2018-01-24 01:11:54', '2018-01-24 01:32:10'),
(105, 'abhishek', NULL, 'abhisekdubey+1@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2018-01-24 01:12:00', '2018-01-24 01:12:00'),
(106, 'akash', 'kumar', 'durgesh+3@singsys.com', '$2y$10$jx/NH2lh5o.DOT.O4WtGwOXJGSH02QF7mkb6XUssZFBNWv0iAuNv6', NULL, '1233654789', 'male', NULL, NULL, 'KBPakWQdEH11fqkHKNgdj1QJRtR2iOgUSmaMoVLtxg7JceLRn1vI5SFvkeC5', NULL, '1', '2018-01-24 01:16:25', '2018-01-24 01:28:49'),
(107, 'Kumar', 'kumar', 'durgesh+4@singsys.com', '$2y$10$Ijg99UU3ir.Id959D0lh6ePRpssCbOaKLsSON1r3Z3rtdg1KlShc6', NULL, '95175323', 'male', NULL, NULL, 'S5jih6krlmdXBbJmTDrR4UUhFE5rmoGD1bFnY2mXD9dmOjFgZRCWWZjevdS9', 'nJQfEnYWEIvXbu4NfigN4hJUCMpemvN9g5VUc087i15z4nefmfaPq7dVjJkX', '1', '2018-01-24 01:16:33', '2018-01-24 01:35:43'),
(108, 'r.d', NULL, 'durgesh+guardian@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2018-01-24 03:15:49', '2018-01-24 03:15:49'),
(109, 'p.l', NULL, 'durgesh+parents@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2018-01-24 03:19:42', '2018-01-24 03:19:42'),
(110, 'r.k', NULL, 'durgesh+rockstar@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2018-01-24 03:21:26', '2018-01-24 03:21:26'),
(111, 'r.d', NULL, 'durgesh+cena@singsys.com', NULL, NULL, NULL, 'male', NULL, NULL, NULL, NULL, '0', '2018-01-24 03:22:51', '2018-01-24 03:22:51');

-- --------------------------------------------------------

--
-- Table structure for table `c_user_roles`
--

CREATE TABLE IF NOT EXISTS `c_user_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `role_status` enum('0','1') DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=132 ;

--
-- Dumping data for table `c_user_roles`
--

INSERT INTO `c_user_roles` (`id`, `user_id`, `role_id`, `role_status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '1', '2017-12-21 17:18:59', '2017-12-21 17:18:59'),
(2, 2, 2, '1', '2017-12-21 17:19:18', '2017-12-21 17:19:18'),
(25, 25, 2, '1', '2017-12-23 05:03:35', '2017-12-23 05:03:35'),
(26, 2, 3, '1', '2017-12-21 17:19:18', '2017-12-21 17:19:18'),
(27, 1, 3, '1', '2017-12-21 17:18:59', '2017-12-21 17:18:59'),
(28, 26, 2, '1', '2017-12-23 08:37:03', '2017-12-23 08:37:03'),
(29, 27, 2, '1', '2017-12-23 14:39:24', '2017-12-23 14:39:24'),
(30, 35, 4, '1', '2017-12-25 09:12:55', '2017-12-25 09:12:55'),
(31, 36, 4, '1', '2017-12-25 09:13:02', '2017-12-25 09:13:02'),
(32, 37, 4, '1', '2017-12-25 11:41:23', '2017-12-25 11:41:23'),
(34, 42, 3, '1', '2017-12-25 22:49:30', '2017-12-25 22:49:30'),
(35, 43, 3, '1', '2017-12-26 04:04:21', '2017-12-26 04:04:21'),
(36, 44, 3, '1', '2017-12-26 05:38:57', '2017-12-26 05:38:57'),
(37, 45, 3, '1', '2017-12-26 05:41:45', '2017-12-26 05:41:45'),
(38, 46, 4, '1', '2017-12-26 05:51:33', '2017-12-26 05:51:33'),
(39, 47, 4, '1', '2017-12-26 05:55:57', '2017-12-26 05:55:57'),
(40, 48, 4, '1', '2017-12-26 05:56:52', '2017-12-26 05:56:52'),
(41, 49, 4, '1', '2017-12-26 05:58:05', '2017-12-26 05:58:05'),
(42, 50, 4, '1', '2017-12-26 12:44:17', '2017-12-26 12:44:17'),
(43, 51, 4, '1', '2017-12-27 10:13:38', '2017-12-27 10:13:38'),
(44, 52, 4, '1', '2017-12-27 10:27:48', '2017-12-27 10:27:48'),
(45, 53, 3, '1', '2018-01-02 05:32:47', '2018-01-02 05:32:47'),
(46, 54, 3, '1', '2018-01-02 09:09:25', '2018-01-02 09:09:25'),
(47, 55, 3, '1', '2018-01-02 09:10:32', '2018-01-02 09:10:32'),
(48, 56, 3, '1', '2018-01-02 09:11:40', '2018-01-02 09:11:40'),
(49, 57, 3, '1', '2018-01-02 09:13:21', '2018-01-02 09:13:21'),
(50, 58, 3, '1', '2018-01-02 09:15:51', '2018-01-02 09:15:51'),
(51, 59, 3, '1', '2018-01-02 09:16:26', '2018-01-02 09:16:26'),
(52, 60, 4, '1', '2018-01-02 09:37:49', '2018-01-02 09:37:49'),
(53, 61, 3, '1', '2018-01-02 09:52:43', '2018-01-02 09:52:43'),
(54, 62, 3, '1', '2018-01-02 09:54:44', '2018-01-02 09:54:44'),
(55, 63, 3, '1', '2018-01-02 09:56:20', '2018-01-02 09:56:20'),
(56, 64, 3, '1', '2018-01-02 09:58:36', '2018-01-02 09:58:36'),
(57, 65, 3, '1', '2018-01-02 09:59:13', '2018-01-02 09:59:13'),
(58, 66, 3, '1', '2018-01-02 11:00:45', '2018-01-02 11:00:45'),
(59, 67, 3, '1', '2018-01-02 11:01:52', '2018-01-02 11:01:52'),
(60, 68, 4, '1', '2018-01-02 13:04:29', '2018-01-02 13:04:29'),
(61, 69, 4, '1', '2018-01-02 13:23:06', '2018-01-02 13:23:06'),
(67, 76, 4, '1', '2018-01-04 07:15:29', '2018-01-04 07:15:29'),
(68, 77, 2, '1', '2018-01-05 12:18:50', '2018-01-05 12:18:50'),
(71, 80, 2, '1', '2018-01-05 12:28:15', '2018-01-05 12:28:15'),
(72, 81, 2, '1', '2018-01-05 12:29:24', '2018-01-05 12:29:24'),
(73, 82, 2, '1', '2018-01-05 12:32:22', '2018-01-05 12:32:22'),
(75, 84, 2, '1', '2018-01-05 12:35:02', '2018-01-05 12:35:02'),
(76, 85, 2, '1', '2018-01-05 12:36:01', '2018-01-05 12:36:01'),
(77, 86, 2, '1', '2018-01-05 12:38:30', '2018-01-05 12:38:30'),
(78, 87, 2, '1', '2018-01-05 12:44:38', '2018-01-05 12:44:38'),
(79, 88, 2, '1', '2018-01-05 12:45:46', '2018-01-05 12:45:46'),
(80, 89, 2, '1', '2018-01-05 12:46:15', '2018-01-05 12:46:15'),
(83, 92, 2, '1', '2018-01-05 13:13:00', '2018-01-05 13:13:00'),
(97, 77, 2, '1', '2018-01-09 10:27:47', '2018-01-09 10:27:47'),
(98, 78, 3, '1', '2018-01-09 10:39:03', '2018-01-09 10:39:03'),
(99, 79, 3, '1', '2018-01-09 10:40:21', '2018-01-09 10:40:21'),
(100, 80, 3, '1', '2018-01-10 06:02:39', '2018-01-10 06:02:39'),
(101, 81, 4, '1', '2018-01-10 16:29:54', '2018-01-10 16:29:54'),
(102, 82, 4, '1', '2018-01-10 16:31:48', '2018-01-10 16:31:48'),
(103, 83, 3, '1', '2018-01-20 04:03:53', '2018-01-20 04:03:53'),
(104, 84, 2, '1', '2018-01-22 09:39:37', '2018-01-22 09:39:37'),
(105, 85, 3, '1', '2018-01-22 09:41:41', '2018-01-22 09:41:41'),
(106, 86, 3, '1', '2018-01-22 09:41:56', '2018-01-22 09:41:56'),
(107, 87, 4, '1', '2018-01-22 10:06:15', '2018-01-22 10:06:15'),
(108, 88, 4, '1', '2018-01-22 10:07:12', '2018-01-22 10:07:12'),
(109, 89, 4, '1', '2018-01-22 10:08:51', '2018-01-22 10:08:51'),
(110, 90, 2, '1', '2018-01-24 04:44:13', '2018-01-24 04:44:13'),
(111, 91, 3, '1', '2018-01-24 04:48:41', '2018-01-24 04:48:41'),
(112, 92, 2, '1', '2018-01-24 05:06:50', '2018-01-24 05:06:50'),
(113, 93, 3, '1', '2018-01-24 05:19:26', '2018-01-24 05:19:26'),
(114, 94, 3, '1', '2018-01-24 05:24:27', '2018-01-24 05:24:27'),
(115, 95, 3, '1', '2018-01-24 05:37:22', '2018-01-24 05:37:22'),
(116, 96, 2, '1', '2018-01-24 05:39:17', '2018-01-24 05:39:17'),
(117, 97, 4, '1', '2018-01-24 05:45:58', '2018-01-24 05:45:58'),
(118, 98, 3, '1', '2018-01-24 05:50:30', '2018-01-24 05:50:30'),
(119, 99, 4, '1', '2018-01-24 05:59:37', '2018-01-24 05:59:37'),
(120, 100, 4, '1', '2018-01-24 06:03:26', '2018-01-24 06:03:26'),
(121, 101, 4, '1', '2018-01-24 06:03:36', '2018-01-24 06:03:36'),
(122, 102, 4, '1', '2018-01-24 06:28:07', '2018-01-24 06:28:07'),
(123, 103, 4, '1', '2018-01-24 06:28:17', '2018-01-24 06:28:17'),
(124, 104, 4, '1', '2018-01-24 06:41:55', '2018-01-24 06:41:55'),
(125, 105, 4, '1', '2018-01-24 06:42:00', '2018-01-24 06:42:00'),
(126, 106, 4, '1', '2018-01-24 06:46:26', '2018-01-24 06:46:26'),
(127, 107, 4, '1', '2018-01-24 06:46:33', '2018-01-24 06:46:33'),
(128, 108, 4, '1', '2018-01-24 08:45:49', '2018-01-24 08:45:49'),
(129, 109, 4, '1', '2018-01-24 08:49:42', '2018-01-24 08:49:42'),
(130, 110, 4, '1', '2018-01-24 08:51:27', '2018-01-24 08:51:27'),
(131, 111, 4, '1', '2018-01-24 08:52:51', '2018-01-24 08:52:51');

-- --------------------------------------------------------

--
-- Table structure for table `c_verification`
--

CREATE TABLE IF NOT EXISTS `c_verification` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `otp_code` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone_no` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `verififcation_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `c_meal`
--
ALTER TABLE `c_meal`
  ADD CONSTRAINT `meal_property_meal_id_foreign` FOREIGN KEY (`property_meal_id`) REFERENCES `c_property_meal` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `meal_std_id_foreign` FOREIGN KEY (`std_id`) REFERENCES `c_students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `meal_type_meal_id_foreign` FOREIGN KEY (`type_meal_id`) REFERENCES `c_type_meal` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `c_notice`
--
ALTER TABLE `c_notice`
  ADD CONSTRAINT `notice_std_id_foreign` FOREIGN KEY (`std_id`) REFERENCES `c_students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `c_parents`
--
ALTER TABLE `c_parents`
  ADD CONSTRAINT `parents_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `c_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `c_property_meal`
--
ALTER TABLE `c_property_meal`
  ADD CONSTRAINT `property_meal_type_meal_id_foreign` FOREIGN KEY (`type_meal_id`) REFERENCES `c_type_meal` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `c_tagging`
--
ALTER TABLE `c_tagging`
  ADD CONSTRAINT `tagging_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `c_parents` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tagging_std_id_foreign` FOREIGN KEY (`std_id`) REFERENCES `c_students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
